#!/usr/bin/env python
"""Pick a day's racecard and a form file, find the
probable winners, then browse races and runners from a simple prompt.

    python winners_cli.py                                   # defaults, same as the GUI
    python winners_cli.py --races data/cards_races_2026-10-23.csv --course Ascot
    python winners_cli.py --list                            # print the picks table and exit

All the real work lives in form_model.py; this file only gathers inputs, shows progress and draws
text tables. That split is the same one the GUI uses, so both front ends always agree on the numbers.
"""

# Everything here is standard library.
import argparse
import logging
import os
import shutil
import sys
from pathlib import Path

# Import form_model as a module (never copy its code in). The cached model is a pickle that refers to
# form_model.Horse, so loading it only works when the class lives under that exact module name.
import form_model as fm

# Default paths are relative to this script, not the current directory, so the program behaves the
# same however it is launched (double-click, cron, another folder...). Same defaults as the GUI.
HERE = Path(__file__).resolve().parent

# A runner whose win chance × price is above this looks like "value" (price bigger than its chance).
# 1.10 rather than 1.00 leaves a margin for model error. The GUI uses the same cut-off for green rows.
VALUE_EDGE = 1.1


# --- colours ------------------------------------------------------------------------------------
# The GUI coloured value picks green and negative reasons red. In a terminal the equivalent is ANSI
# escape codes. They are switched off when output isn't a terminal (piped to a file / less) or when
# the user sets NO_COLOR (https://no-color.org), otherwise files fill up with "\x1b[32m" junk.

USE_COLOUR = sys.stdout.isatty() and "NO_COLOR" not in os.environ
if os.name == "nt" and USE_COLOUR:
    os.system("")  # odd but documented trick: makes the Windows console honour ANSI codes


def paint(text, code):
    """Wrap text in an ANSI colour code if colour is on; otherwise return it untouched."""
    return f"\x1b[{code}m{text}\x1b[0m" if USE_COLOUR else text


def green(t): return paint(t, "32")
def red(t): return paint(t, "31")
def bold(t): return paint(t, "1")
def grey(t): return paint(t, "90")


# --- small formatting helpers (identical in spirit to the GUI's) ----------------------------------

def pct(p):
    """0.234 -> '23%'. Whole percents are plenty; the model isn't accurate to decimals."""
    return f"{100 * p:.0f}%"


def price_text(d):
    """Decimal price, or blank when the card had no price (None / 0)."""
    return f"{round(d, 2):g}" if d else ""  # 4.3333 -> 4.33 so it fits the column


def value_of(runner, key):
    """Win chance × price, or None if there's no price. Above VALUE_EDGE suggests an overlay."""
    return runner["price"] * runner[key] if runner["price"] else None


# --- table drawing ------------------------------------------------------------------------------
# Here we print fixed-width columns.Each
# column is (title, width, align); cells longer than the width are cut with "…" so rows never wrap,
# because wrapped rows make a table unreadable.

def fit(text, width, align="<"):
    text = str(text)
    if len(text) > width:
        text = text[:width - 1] + "…"
    return f"{text:{align}{width}}"


def print_table(cols, rows, row_colour=None):
    """cols: [(title, width, align)]. rows: lists of cell values. row_colour(i) -> paint fn or None.

    Colour is applied to the whole finished line, after padding, because ANSI codes are invisible
    characters: padding a coloured string would count them and throw the columns out of line.
    """
    print(bold("  ".join(fit(t, w, a) for t, w, a in cols)))
    print("  ".join("-" * w for _, w, _ in cols))
    for i, row in enumerate(rows):
        line = "  ".join(fit(v, w, a) for v, (_, w, a) in zip(row, cols))
        colour = row_colour(i) if row_colour else None
        print(colour(line) if colour else line)


def rule(title=""):
    """A full-width separator so each screen of output is easy to spot when scrolling back."""
    width = shutil.get_terminal_size((100, 20)).columns
    print("\n" + bold(f"== {title} ".ljust(width, "=")))


# --- progress -----------------------------------------------------------------------------------
# Building the model can take several minutes, so we need visible progress. The GUI used a
# Progressbar fed through a queue from a worker thread. A terminal app has no event loop to keep
# responsive, so we simply call the model in the main thread and redraw one line with "\r".
# Ctrl-C replaces the GUI's Stop button: it raises KeyboardInterrupt straight out of the training
# loop. That is safe because form_model only writes the cache file after training has finished.

class Progress:
    def __init__(self):
        # Only draw the bar on a real terminal; in a log file "\r" redraws would be a mess, so there
        # we fall back to a plain line every 10%.
        self.tty = sys.stderr.isatty()
        self.last_tenth = -1

    def __call__(self, frac, msg):
        if self.tty:
            width = 30
            filled = int(frac * width)
            bar = "#" * filled + "." * (width - filled)
            # Pad with spaces so a shorter message fully overwrites a longer one before it.
            sys.stderr.write(f"\r[{bar}] {100 * frac:3.0f}%  {msg[:60]:<60}")
            sys.stderr.flush()
        elif int(frac * 10) != self.last_tenth:
            self.last_tenth = int(frac * 10)
            print(f"{msg} ({100 * frac:.0f}%)", file=sys.stderr)

    def finish(self):
        if self.tty:
            sys.stderr.write("\n")


# --- loading ------------------------------------------------------------------------------------

def parse_args(argv):
    """Command-line options stand in for  file boxes, checkbox and filters."""
    p = argparse.ArgumentParser(description="Probable winners in the terminal (no Tkinter needed)")
    p.add_argument("--form", type=Path, default=HERE / "raceform.csv", help="past form CSV")
    p.add_argument("--races", type=Path, default=HERE / "sample.csv", help="cards_races CSV for the day")
    p.add_argument("--runners", type=Path,
                   help="cards_runners CSV (default: worked out from the races file's date)")
    p.add_argument("--rebuild", action="store_true", help="rebuild the model even if a cache exists")
    p.add_argument("--course", help="only show this course (can be changed later with 'c')")
    p.add_argument("--rank", choices=("market", "form"), default="market",
                   help="rank by form + market (default) or form only")
    p.add_argument("--export", type=Path, help="write the picks CSV here")
    p.add_argument("--list", action="store_true", help="print the races table and exit (no prompt)")
    return p.parse_args(argv)


def check_files(form, races, runners):
    """Same sanity checks the GUI did before pressing Go, returned as an error message or None.

    Catching these early gives a clear message instead of a traceback halfway through loading.
    """
    missing = [str(p) for p in (form, races, runners) if not p.is_file()]
    if missing:
        return "Can't find:\n  " + "\n  ".join(missing)
    # Easy mistake: choosing the cached .pkl model instead of the form CSV it was built from.
    models = [str(p) for p in (form, races, runners) if p.suffix == ".pkl"]
    if models:
        return ("These are cached model files, not CSVs:\n  " + "\n  ".join(models) +
                "\nPass the form CSV (e.g. raceform.csv); the model is loaded from it automatically.")
    return None


def setup_logging():
    """form_model reports what it is doing through logging. Send that to stderr with timestamps,
    like the GUI's log pane, keeping stdout for the actual results (so they can be piped)."""
    handler = logging.StreamHandler(sys.stderr)
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s", "%H:%M:%S"))
    fm.log.addHandler(handler)
    fm.log.setLevel(logging.INFO)


def stats_line(model):
    """One-line summary of how the model did on held-out races, so the user knows how far to trust
    it. Shows each race kind's pick strike rate against form-only and the SP favourite."""
    s = model["stats"]
    parts = []
    for kind in ("flat", "jumps"):
        if (kind, "market") in s:
            m, f = s[(kind, "market")], s[(kind, "form")]
            parts.append(f"{kind}: pick won {100 * m['top_pick']:.0f}% (form only "
                         f"{100 * f['top_pick']:.0f}%, SP fav {100 * m['favourite']:.0f}%)")
    return (f"Tested on races since {model['holdout_from']} — " + "; ".join(parts)
            + f".  Form file ends {model['form_last']}.")


# --- the browser --------------------------------------------------------------------------------
# All the interactive state lives in one small class: the cards, the current filter / ranking and
# which race is open. The GUI kept the same things as widget variables; here they are plain fields.

class Browser:
    def __init__(self, model, cards, course=None, rank="market"):
        self.model = model
        self.cards = cards
        self.rank = rank            # "market" (form + market) or "form" (form only)
        self.course = None          # None means all courses
        self.race = None            # the race dict currently open, if any
        self.runners = []           # that race's runners in the order last shown (for numbering)
        self.shown = []             # races in the order last listed (so "3" means the third row)
        if course:
            self.set_course(course)

    # Every probability lookup goes through this key, so flipping self.rank re-ranks everything.
    @property
    def key(self):
        return "p_" + self.rank

    def ranked(self, rc):
        """A race's runners, best first, under the current ranking."""
        return sorted(rc["runners"], key=lambda r: -r[self.key])

    def courses(self):
        return sorted({rc["course"] for rc in self.cards})

    def set_course(self, text):
        """Match a course loosely (case-insensitive prefix) so 'asc' finds 'Ascot'; typing exact
        names at a prompt is annoying in a way picking from a GUI dropdown never was."""
        if not text:
            self.course = None
            return True
        hits = [c for c in self.courses() if c.lower().startswith(text.lower())]
        if len(hits) == 1:
            self.course = hits[0]
            return True
        print(f"No single course matches '{text}'. Courses: " + ", ".join(self.courses()))
        return False

    # -- race list (the GUI's top table) --

    def list_races(self):
        self.shown = [rc for rc in self.cards if not self.course or rc["course"] == self.course]
        label = "form only" if self.rank == "form" else "form + market"
        rule(f"{self.course or 'All courses'} — ranked by {label}")
        cols = [("No", 3, ">"), ("Time", 5, "<"), ("Course", 12, "<"), ("Race", 30, "<"),
                ("Type", 5, "<"), ("Rn", 3, ">"), ("Pick", 20, "<"), ("Win%", 4, ">"),
                ("Fair", 5, ">"), ("Price", 5, ">"), ("Next best", 22, "<"), ("Form-only", 22, "<")]
        rows, value_rows = [], set()
        for n, rc in enumerate(self.shown, 1):
            r = self.ranked(rc)
            top = r[0]
            v = value_of(top, self.key)
            if v and v > VALUE_EDGE:
                value_rows.add(n - 1)
            rows.append([n, rc["time"], rc["course"], rc["race_name"], rc["kind"], len(r), top["horse"],
                         pct(top[self.key]), fm.fair_odds(top[self.key]), price_text(top["price"]),
                         f"{r[1]['horse']} {pct(r[1][self.key])}" if len(r) > 1 else "",
                         f"{rc['form_pick']} {pct(rc['form_pick_p'])}"])
        print_table(cols, rows, lambda i: green if i in value_rows else None)
        print(grey(f"{len(self.shown)} races. Green = pick's price looks bigger than its chance."))

    # -- one race (the GUI's runner table + detail pane) --

    def open_race(self, rc, sort_col=None):
        self.race = rc
        self.runners = self.ranked(rc)
        # Optional re-sort by another column, replacing the GUI's clickable headings. Sorting the
        # underlying numbers (not the printed text) avoids "10" sorting before "9".
        if sort_col:
            self.runners.sort(key=lambda u: RUNNER_SORTS[sort_col](u, self.key))
        rule(f"{rc['time']} {rc['course']} — {rc['race_name']}")
        print(f"{rc.get('distance', '')}, {rc.get('going', '')}, class {rc.get('race_class') or '-'}"
              f", {len(rc['runners'])} runners")
        cols = [("#", 3, ">"), ("Horse", 20, "<"), ("Win%", 4, ">"), ("Fair", 5, ">"), ("Price", 5, ">"),
                ("Value", 5, ">"), ("Form%", 5, ">"), ("F#", 3, ">"), ("OR", 3, ">"), ("Form", 8, "<"),
                ("Days", 4, ">"), ("Last-run clues", 24, "<"), ("Jockey", 16, "<"), ("Spot", 4, "<")]
        rows, colours = [], {}
        for n, u in enumerate(self.runners, 1):
            v = value_of(u, self.key)
            # Top pick in bold, value runners in green (both when both), just like the GUI tags.
            if v and v > VALUE_EDGE:
                colours[n - 1] = (lambda t: bold(green(t))) if n == 1 else green
            elif n == 1 and not sort_col:
                colours[n - 1] = bold
            rows.append([n, u["horse"], pct(u["p_market"]), fm.fair_odds(u[self.key]), price_text(u["price"]),
                         f"{v:.2f}" if v else "", pct(u["p_form"]), u["form_rank"],
                         u.get("official_rating", ""), u.get("form", ""), u.get("last_ran_days", ""),
                         u["last_clues"], u.get("jockey", ""), u.get("verdict_pick", "")])
        print_table(cols, rows, colours.get)
        if rc.get("verdict"):
            print("\n" + bold("Spotlight") + "\n" + rc["verdict"])
        if rc.get("betting_forecast"):
            print("\n" + bold("Betting forecast") + "\n" + rc["betting_forecast"])
        print(grey("\nValue = win % × price; over 1.10 (green) means the price looks bigger than the "
                   "horse's chance."))

    # -- one runner (the GUI's detail pane when a runner is clicked) --

    def show_runner(self, u):
        rule(u["horse"])
        print(bold(f"{u['horse']}  —  {pct(u['p_market'])} (form only {pct(u['p_form'])})"))
        print(f"Age {u.get('horse_age', '')}, {u.get('weight', '')}, OR {u.get('official_rating') or '-'}"
              f", form {u.get('form') or '-'}, {u.get('last_ran_days') or '?'} days since last run")
        print(f"{u.get('jockey', '')} / {u.get('trainer', '')}")
        if not u["in_form_file"]:
            # Be upfront when the model is working from thin data, so a pick isn't over-trusted.
            print(grey(f"No runs in the form file (it ends {self.model['form_last']}): "
                       "using the card's last 3 runs and career totals."))
        # The "reasons" are the model's biggest pushes up or down for this horse relative to the
        # field; they explain *why* it rates where it does, which a bare percentage can't.
        print("\n" + bold("Why (strongest first)"))
        reasons = u["reasons_" + self.rank]
        if not reasons:
            print("Nothing stands out from the field average.")
        for label, v in reasons[:10]:
            print(green(f"▲ {label}") if v > 0 else red(f"▼ {label}"))
        if u["last_comment"]:
            print("\n" + bold("Last run") + "\n" + u["last_comment"])
        # The card carries the horse's last few runs in numbered columns (last1_date, last2_date...).
        recent = [i for i in range(1, fm.RECENT + 1) if u.get(f"last{i}_date")]
        if recent:
            print("\n" + bold("Recent runs (card)"))
        for i in recent:
            print(f"{u[f'last{i}_date']} {u.get(f'last{i}_course', '')} "
                  f"{u.get(f'last{i}_pos', '')}/{u.get(f'last{i}_ran', '')} "
                  f"{u.get(f'last{i}_dist', '')} {u.get(f'last{i}_going', '')} {u.get(f'last{i}_odds', '')}")
        if u.get("commentary"):
            print("\n" + bold("Spotlight") + "\n" + u["commentary"])

    # -- the prompt loop --
    # A tiny command language instead of buttons. Numbers mean "open that row" in whichever table is
    # on screen, so the common path (list -> race -> runner) is just typing numbers.

    HELP = """Commands:
  <n>          open race n (from the race list) or runner n (inside a race)
  b            back to the race list
  l            list races again
  c [course]   show one course (prefix is enough); 'c' alone shows all
  r            switch ranking: form + market <-> form only
  s <col>      inside a race, sort runners by: """ + ", ".join(
        ["win", "form", "price", "value", "or", "days", "horse"]) + """
  e [file]     export picks to CSV (default data/picks_<date>.csv)
  q            quit"""

    def run(self):
        self.list_races()
        print(grey("Type a number to open a race, ? for help, q to quit."))
        while True:
            where = f"{self.race['time']} {self.race['course']}" if self.race else "races"
            try:
                line = input(f"\n[{where}] > ").strip()
            except (EOFError, KeyboardInterrupt):
                # Ctrl-D / Ctrl-C at the prompt should just leave quietly, not dump a traceback.
                print()
                return
            cmd, _, arg = line.partition(" ")
            cmd, arg = cmd.lower(), arg.strip()
            if not cmd:
                continue
            if cmd in ("q", "quit", "exit"):
                return
            if cmd in ("?", "h", "help"):
                print(self.HELP)
            elif cmd.isdigit():
                self.open_number(int(cmd))
            elif cmd in ("b", "l"):
                self.race = None
                self.list_races()
            elif cmd == "c":
                if self.set_course(arg):
                    self.race = None
                    self.list_races()
            elif cmd == "r":
                self.rank = "form" if self.rank == "market" else "market"
                # Re-draw whatever is on screen so the switch is visible immediately.
                self.open_race(self.race) if self.race else self.list_races()
            elif cmd == "s":
                if not self.race:
                    print("Open a race first, then sort its runners.")
                elif arg not in RUNNER_SORTS:
                    print("Sort by one of: " + ", ".join(RUNNER_SORTS))
                else:
                    self.open_race(self.race, arg)
            elif cmd == "e":
                export(self.cards, Path(arg) if arg else None)
            else:
                print(f"Unknown command '{cmd}'. Type ? for help.")

    def open_number(self, n):
        # Meaning depends on context: inside a race the number is a runner, otherwise a race.
        # Numbers are 1-based on screen because that's what people count with.
        items = self.runners if self.race else self.shown
        if not 1 <= n <= len(items):
            print(f"Pick a number from 1 to {len(items)}.")
        elif self.race:
            self.show_runner(items[n - 1])
        else:
            self.open_race(items[n - 1])


def _num(v):
    """Turn a card field like '84' / '' / None into a float for sorting; blanks sort last."""
    try:
        return float(v)
    except (TypeError, ValueError):
        return float("inf")


# Sort options for runners: name -> key function taking (runner, probability key). Kept as data so the
# help text, the validation and the sorting all come from one place and can't drift apart. "value"
# uses the current ranking's probability so it sorts by exactly the Value column on screen.
# Probabilities and value sort high-first; price, days and OR go the way a punter would expect.
# Missing values map to infinity so blanks always end up at the bottom.
RUNNER_SORTS = {
    "win": lambda u, k: -u["p_market"],
    "form": lambda u, k: -u["p_form"],
    "price": lambda u, k: u["price"] or float("inf"),
    "value": lambda u, k: -(u["price"] * u[k]) if u["price"] else float("inf"),
    "or": lambda u, k: -_num(u.get("official_rating")) if u.get("official_rating") else float("inf"),
    "days": lambda u, k: _num(u.get("last_ran_days")),
    "horse": lambda u, k: u["horse"].lower(),
}


def export(cards, path=None):
    """Write the picks CSV via form_model so the file format matches the GUI's export exactly."""
    if path is None:
        day = cards[0]["date"] if cards else "day"
        path = HERE / "data" / f"picks_{day}.csv"
    path.parent.mkdir(parents=True, exist_ok=True)
    fm.write_picks(cards, path)
    print(f"wrote {path}")


# --- main ---------------------------------------------------------------------------------------

def main(argv=None):
    a = parse_args(argv)
    setup_logging()

    # The runners file is usually found automatically from the races file's date, same as the GUI's
    # autofill; --runners is only needed when the files live somewhere unusual.
    runners = a.runners
    if runners is None:
        try:
            runners = fm.runners_path_for(a.races)
        except (OSError, KeyError):
            runners = None
        if runners is None:
            return f"No runners file found for {a.races}; pass --runners data/cards_runners_<date>.csv"

    problem = check_files(a.form, a.races, Path(runners))
    if problem:
        return problem  # returning a string from main makes sys.exit print it and exit with status 1

    progress = Progress()
    try:
        # load_or_train reuses the cached model when the form file hasn't changed, so after the
        # first (slow) run this is near-instant. --rebuild forces a fresh fit, like the checkbox.
        model = fm.load_or_train(a.form, HERE / "data", a.rebuild, on_progress=progress)
        cards = fm.predict_card(model, a.races, runners)
    except KeyboardInterrupt:
        progress.finish()
        return "Stopped."
    progress.finish()

    if not cards:
        return "No races with runners found in that card."
    print(grey(stats_line(model)))
    print(grey("Prices are decimal. Win % comes from a model fitted to the form file; "
               "nothing about the day's results is used."))

    if a.export:
        export(cards, a.export)

    browser = Browser(model, cards, a.course, a.rank)
    if a.list or not sys.stdin.isatty():
        # Non-interactive: print the table once. Also the fallback when stdin isn't a keyboard
        # (e.g. run from cron), where a prompt would just hang or hit EOF.
        browser.list_races()
    else:
        browser.run()
    return 0


if __name__ == "__main__":
    sys.exit(main())
