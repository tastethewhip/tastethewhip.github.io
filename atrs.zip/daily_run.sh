#!/usr/bin/env bash
# One command for the day's picks on Kaggle: scrape the racecard, upload it (and the current code)
# to the winners-code dataset, re-run the "Prediction - v 1.0.0" notebook on it, then print its output.
#
#   ./daily_run.sh                                  # scrape today's cards, then run
#   ./daily_run.sh 2026-10-24                       # scrape that day's cards, then run
#   ./daily_run.sh data/cards_races_2026-10-24.csv  # use cards already scraped
#
# The notebook is pulled fresh from Kaggle before each push, so edits made on the website are kept.
set -euo pipefail
cd "$(dirname "$0")"

# `python -m kaggle`, not `kaggle`: the plain command here is a desktop shortcut, not the CLI.
KAGGLE=(python -m kaggle)
DATASET=deltaromeo/winners-code
NOTEBOOK=deltaromeo/prediction-v-1-0-0
# Cards are published around midnight; if they're not up yet, try again this often, this many times.
RETRY_MINUTES=15
RETRIES=8

die() { echo "$*" >&2; exit 1; }
has_rows() { [ "$(wc -l < "$1")" -gt 1 ]; }

# --- get the day's cards ------------------------------------------------------------------------
if [[ "${1:-}" == *.csv ]]; then
    races=$1
    [ -f "$races" ] || die "No such file: $races"
    day=$(basename "$races" .csv)
    day=${day#cards_races_}
else
    day=${1:-$(date +%F)}
    races=data/cards_races_$day.csv
    # Cards scraped before they're published come out as just a header row, so keep trying.
    for try in $(seq "$RETRIES"); do
        echo "== Scraping UK/Ireland cards for $day (takes a few minutes)"
        python sl_racecards.py --date "$day" --uk-ire
        has_rows "$races" && break
        [ "$try" -lt "$RETRIES" ] || die "Still no cards for $day after $RETRIES tries; run this again later."
        echo "   No cards for $day yet. Trying again in $RETRY_MINUTES minutes (Ctrl-C to give up)."
        sleep $((RETRY_MINUTES * 60))
    done
fi
runners="$(dirname "$races")/$(basename "$races" | sed 's/cards_races_/cards_runners_/')"
[ -f "$runners" ] || die "No runners file to go with it: $runners"
# Uploading an empty card would make the notebook pick this empty day as the newest, so stop instead.
for f in "$races" "$runners"; do
    has_rows "$f" || die "$f has no races yet (cards are usually published around midnight)."
done

# --- upload -------------------------------------------------------------------------------------
echo "== Uploading cards for $day to $DATASET"
cp "$races" "$runners" notebook_sample_files/winners_cli.py notebook_sample_files/form_model.py kaggle_code/
# Newest file date in the dataset now; the new version is live once this changes.
newest() { "${KAGGLE[@]}" datasets files "$DATASET" -v | tail -n +2 | cut -d, -f3 | sort | tail -1; }
before=$(newest)
"${KAGGLE[@]}" datasets version -p kaggle_code -t -q -m "Cards for $day"
for _ in $(seq 60); do
    [ "$(newest)" != "$before" ] && [ "$("${KAGGLE[@]}" datasets status "$DATASET")" = ready ] && break
    sleep 10
done
[ "$(newest)" != "$before" ] || die "New dataset version still not ready after 10 minutes; try again later."

# --- run the notebook ---------------------------------------------------------------------------
echo "== Starting a fresh run of $NOTEBOOK"
rm -rf kaggle_notebook
"${KAGGLE[@]}" kernels pull "$NOTEBOOK" -p kaggle_notebook -m
"${KAGGLE[@]}" kernels push -p kaggle_notebook

echo "== Waiting for the run to finish (building the model takes a few minutes)"
status=""
for _ in $(seq 120); do
    sleep 30
    status=$("${KAGGLE[@]}" kernels status "$NOTEBOOK" 2>&1 | grep -oiE 'status "[^"]*"' || true)
    echo "   $(date +%H:%M) ${status:-waiting for Kaggle}"
    case "${status,,}" in
        *complete*) break ;;
        *error*|*cancel*) die "Run failed: see https://www.kaggle.com/code/$NOTEBOOK" ;;
    esac
done
[[ "${status,,}" == *complete* ]] || die "Still not finished after an hour: see https://www.kaggle.com/code/$NOTEBOOK"

# --- fetch the output ---------------------------------------------------------------------------
out=kaggle_output/$day
rm -rf "$out"
"${KAGGLE[@]}" kernels output "$NOTEBOOK" -p "$out" -q
# The run log is a JSON list of {stream_name, time, data}; print the notebook's printed output.
log=$(ls "$out"/*.log 2>/dev/null | head -1)
if [ -n "$log" ]; then
    python - "$log" <<'EOF'
import json, sys
for entry in json.load(open(sys.argv[1])):
    sys.stdout.write(entry.get("data", ""))
EOF
fi
echo
echo "== Done. Output saved in $out/  (notebook: https://www.kaggle.com/code/$NOTEBOOK)"
