#!/usr/bin/env python
"""Find a day's probable winners from a racecard and a history of past form.

Learns how much each pre-race clue matters (recent positions, official rating, course/distance/going
wins, class moves, trainer and jockey strike rates, in-running comments from recent runs and,
optionally, the price) by fitting a conditional logit model to every race in the form file, then
gives each runner on the card a win probability.

Nothing about a race is used to predict it: features only use runs from earlier days, and trainer
and jockey strike rates are only updated once a day's racing is over.

Inputs:
    form file     rpscrape/Racing Post-style results CSV (e.g. sample_form.csv), oldest first
    races file    sl_racecards cards_races_<date>.csv (e.g. sample.csv)
    runners file  sl_racecards cards_runners_<date>.csv; its last1_*..last3_* runs fill the gap
                  between the end of the form file and the race day

Examples:
    python form_model.py --races sample.csv --runners data/cards_runners_2026-10-21.csv
    python form_model.py --races sample.csv --rebuild
"""

import argparse
import csv
import itertools
import logging
import math
import os
import pickle
import re
import sys
from collections import deque
from datetime import date
from pathlib import Path

import numpy as np

log = logging.getLogger("form_model")

MODEL_VERSION = 1
TRAIN_FROM = "2021-01-01"   # races before this only build up horse histories
WARM_UP_DAYS = 365  # with a years limit, the first year read only builds up horse histories
HOLDOUT_FROM = "2026-01-01"  # races from here are held back to measure accuracy
RIDGE = 1.0
RECENT = 3  # past runs kept per horse
SR_DAYS = 365  # trainer/jockey strike-rate window

# In-running comment clues. Both Racing Post ("Tracked leaders - effort 3 out") and Sporting Life
# ("Chased leader, ridden 3f out") wording is covered.
CLUES = {
    "trouble": r"hampered|short of room|no clear run|not clear run|not much room|denied (a )?(clear )?run"
               r"|blocked|checked|squeezed|bumped|interfered|slowly away|slow start|started slowly"
               r"|missed the break|dwelt|stumbled|switched|carried (left|right)|unlucky|nowhere to go"
               r"|lost (his|her|its)? ?(action|footing)|awkward",
    "finish": r"stayed on|ran on|finished (well|strongly)|keeping on|kept on|never nearer|nearest finish"
              r"|closing|late headway|best at finish|gaining|picked up",
    "weaken": r"weakened|faded|no extra|found little|found nothing|tired|tailed off|always (in rear|behind)"
              r"|never (a factor|dangerous|on terms)|outpaced|lost (place|position|touch|ground)"
              r"|dropped away|struggling|soon beaten|no impression|one pace|one-paced|pulled up",
    "easy": r"easily|comfortably|cosily|readily|impressive|won (going )?away|eased (down|close home|near finish)"
            r"|not extended|plenty in hand|hands and heels",
    "green": r"green|inexperience|needed (the )?run|backward",
    "prominent": r"\bled\b|made all|made most|prominent|tracked (the )?leaders?|chased (the )?leaders?"
                 r"|disputed (the )?lead|pressed (the )?leader|close up",
}
CLUE_RE = {k: re.compile(v, re.I) for k, v in CLUES.items()}
CLUE_NAMES = list(CLUES)

# (name, plain-English label) for every model input; "mkt" is only used by the market models.
FEATURES = [
    ("mkt", "market price"),
    ("or_rel", "official rating vs best in field"),
    ("or_missing", "no official rating"),
    ("wgt_rel", "weight carried vs field"),
    ("age_rel", "age vs field"),
    ("debut", "first run"),
    ("log_runs", "experience"),
    ("win_rate", "career strike rate"),
    ("place_rate", "career place rate"),
    ("last_score", "last run position"),
    ("avg3_score", "last 3 runs' positions"),
    ("won_last", "won last time"),
    ("nf_last", "didn't finish last time"),
    ("log_days", "days since last run"),
    ("long_abs", "off 6+ months"),
    ("class_drop", "dropping in class"),
    ("dist_change", "distance change"),
    ("course_win", "course winner"),
    ("dist_win", "distance winner"),
    ("cd_win", "course & distance winner"),
    ("going_win", "won on similar going"),
    ("hg_first", "first-time headgear"),
    ("trainer_sr", "trainer strike rate"),
    ("jockey_sr", "jockey strike rate"),
    ("c_trouble", "trouble in running last time"),
    ("c_finish", "finished strongly last time"),
    ("c_weaken", "weakened last time"),
    ("c_easy", "won/ran easily last time"),
    ("c_green", "ran green / needed the run"),
    ("c_prominent", "races prominently"),
    ("c_trouble_beaten", "hard-luck loser last time"),
    ("c_finish_beaten", "closing loser last time"),
]
FEATURE_NAMES = [f for f, _ in FEATURES]
LABELS = dict(FEATURES)
FX = {f: i for i, f in enumerate(FEATURE_NAMES)}
FORM_ONLY = [i for i, f in enumerate(FEATURE_NAMES) if f != "mkt"]
ALL_FEATURES = list(range(len(FEATURE_NAMES)))

NON_FINISH = {"PU", "RR", "REF", "RO", "CO", "F"}  # count as a failed run
MISHAP = {"UR", "BD", "SU", "DSQ", "-", "", "VOI"}  # ignored when scoring a run


# --- parsing -----------------------------------------------------------------

def norm_name(name):
    """'Scarlett's Spell (IRE)' -> 'scarlettsspell'."""
    return re.sub(r"[^a-z0-9]", "", re.sub(r"\s*\([A-Z]{2,3}\)\s*$", "", name or "", flags=re.I).lower())


def norm_course(name):
    """'Kempton (AW)' -> 'kempton', 'Epsom Downs' -> 'epsom'."""
    s = re.sub(r"\(.*?\)", "", (name or "").lower())
    return re.sub(r"[^a-z]", "", s.replace("downs", ""))


def norm_person(name):
    """Trainer/jockey key: initials of first names + surname, so 'Ralph Beckett' ~ 'R M Beckett'."""
    parts = re.sub(r"[^a-z' -]", "", (name or "").lower()).split()
    return f"{parts[0][0]} {parts[-1]}" if len(parts) > 1 else (parts[0] if parts else "")


def furlongs(text):
    """'2m3½f', '1m 2f', '5f 180y' -> furlongs."""
    s = (text or "").replace("½", ".5")
    m = re.search(r"(\d+)m", s)
    f = re.search(r"([\d.]+)f", s)
    y = re.search(r"(\d+)y", s)
    total = (int(m[1]) * 8 if m else 0) + (float(f[1]) if f else 0) + (int(y[1]) / 220 if y else 0)
    return total or None


def going_code(text):
    """0 (firm) .. 5 (heavy); 'aw' for all-weather surfaces; None if unknown."""
    g = (text or "").lower().split("(")[0].strip()
    if not g:
        return None
    if any(w in g for w in ("standard", "slow", "fast")):
        return "aw"
    # Checked in this order so 'good to soft' isn't taken as 'soft', etc.
    for word, code in (("heavy", 5), ("good to soft", 3), ("soft", 4), ("yielding", 3),
                       ("good to firm", 1), ("firm", 0), ("good", 2)):
        if word in g:
            return code
    return None


def race_class(text):
    m = re.search(r"\d", str(text or ""))
    return int(m[0]) if m else None


def pounds(text):
    m = re.match(r"\s*(\d+)-(\d+)", text or "")
    return int(m[1]) * 14 + int(m[2]) if m else None


def decimal_odds(text):
    """'6/1' -> 7.0, '1/3F' -> 1.33, 'Evs' -> 2.0; '7' (already decimal) -> 7.0."""
    s = re.sub(r"[A-Za-z]+$", "", (text or "").strip())
    if not s:
        return 2.0 if (text or "").strip().lower().startswith("ev") else None
    m = re.match(r"(\d+(?:\.\d+)?)/(\d+(?:\.\d+)?)$", s)
    try:
        return 1 + float(m[1]) / float(m[2]) if m else float(s)
    except (ValueError, ZeroDivisionError):
        return None


def to_float(text):
    try:
        return float(text)
    except (TypeError, ValueError):
        return None


def clean_comment(text):
    """Drop the betting tail Racing Post appends: '...pushed out(op 1/2)'."""
    return re.sub(r"\((op|tchd|nt|bt)\b.*$", "", text or "", flags=re.I).strip()


def clues(comment):
    c = clean_comment(comment)
    return tuple(1 if CLUE_RE[k].search(c) else 0 for k in CLUE_NAMES)


def ordinal(d):
    return date.fromisoformat(d).toordinal()


# --- horse and connections state -------------------------------------------------

class Horse:
    """What is known about a horse before its next run."""
    __slots__ = ("runs", "wins", "places", "last_hg", "recent", "win_spots")

    def __init__(self):
        self.runs = self.wins = self.places = 0
        self.last_hg = ""
        self.recent = []  # newest first: (date_ord, score, won, nf, cls, dist, clue tuple, comment, course, pos)
        self.win_spots = []  # (course, dist, going) of every win

    def add_run(self, day, course, dist, going, cls, pos, ran, comment, hg=None):
        p = str(pos or "").strip().upper()
        won = p == "1"
        nf = p in NON_FINISH
        if p.isdigit():
            n = int(p)
            score = 1 - (n - 1) / max((ran or n) - 1, 1)
            self.places += n <= 3
        elif nf:
            score = 0.0
        else:
            score = None
        self.runs += 1
        self.wins += won
        if won:
            self.win_spots.append((course, dist, going))
        if hg is not None:
            self.last_hg = hg
        self.recent.insert(0, (day, score, won, nf, cls, dist, clues(comment), clean_comment(comment), course, p))
        del self.recent[RECENT:]

    @property
    def last_day(self):
        return self.recent[0][0] if self.recent else None


class StrikeRate:
    """Wins/runs over the last SR_DAYS days for trainers or jockeys."""

    def __init__(self):
        self.hist = {}  # key -> deque of (day, won)
        self.counts = {}  # key -> [runs, wins]

    def add(self, key, day, won):
        if not key:
            return
        self.hist.setdefault(key, deque()).append((day, won))
        c = self.counts.setdefault(key, [0, 0])
        c[0] += 1
        c[1] += won

    def rate(self, key, day):
        h = self.hist.get(key)
        if not h:
            return 0.1
        c = self.counts[key]
        while h and h[0][0] < day - SR_DAYS:
            _, w = h.popleft()
            c[0] -= 1
            c[1] -= w
        return (c[1] + 1) / (c[0] + 10)  # shrunk towards 10%


# --- features --------------------------------------------------------------------

def runner_features(horse, race, run, trainers, jockeys):
    """Raw (not yet race-relative) feature values for one runner, from pre-race knowledge only.

    race: dict(day, course, dist, going, cls); run: dict(or_, wgt, age, odds, hg_first, trainer, jockey).
    """
    x = dict.fromkeys(FEATURE_NAMES, 0.0)
    x["mkt"] = run["odds"]  # decimal; turned into log-probability per race
    x["or_rel"] = run["or_"]
    x["wgt_rel"] = run["wgt"]
    x["age_rel"] = run["age"]
    x["hg_first"] = float(run["hg_first"])
    x["trainer_sr"] = trainers.rate(run["trainer"], race["day"])
    x["jockey_sr"] = jockeys.rate(run["jockey"], race["day"])
    if horse is None or not horse.recent:
        x["debut"] = 1.0
        return x
    rec = horse.recent
    last = rec[0]
    x["log_runs"] = math.log1p(horse.runs)
    x["win_rate"] = (horse.wins + 0.5) / (horse.runs + 4)
    x["place_rate"] = (horse.places + 1) / (horse.runs + 4)
    x["last_score"] = last[1] if last[1] is not None else 0.5
    scores = [r[1] for r in rec if r[1] is not None]
    x["avg3_score"] = sum(scores) / len(scores) if scores else 0.5
    x["won_last"] = float(last[2])
    x["nf_last"] = float(last[3])
    days = race["day"] - last[0]
    x["log_days"] = math.log1p(max(days, 0))
    x["long_abs"] = float(days >= 180)
    if race["cls"] and last[4]:
        x["class_drop"] = race["cls"] - last[4]
    if race["dist"] and last[5]:
        x["dist_change"] = abs(math.log(race["dist"] / last[5]))
    d, g, c = race["dist"], race["going"], race["course"]
    for wc, wd, wg in horse.win_spots:
        near = bool(d and wd and abs(wd - d) <= 0.1 * d)
        x["course_win"] = max(x["course_win"], float(wc == c))
        x["dist_win"] = max(x["dist_win"], float(near))
        x["cd_win"] = max(x["cd_win"], float(wc == c and near))
        if g is not None and wg is not None:
            same = g == wg if "aw" in (g, wg) else abs(g - wg) <= 1
            x["going_win"] = max(x["going_win"], float(same))
    cl = dict(zip(CLUE_NAMES, last[6]))
    for k in ("trouble", "finish", "weaken", "easy", "green"):
        x[f"c_{k}"] = float(cl[k])
    x["c_prominent"] = sum(r[6][CLUE_NAMES.index("prominent")] for r in rec) / len(rec)
    beaten = 0.0 if last[2] else 1.0
    x["c_trouble_beaten"] = x["c_trouble"] * beaten
    x["c_finish_beaten"] = x["c_finish"] * beaten
    return x


def race_matrix(raw):
    """Turn a race's raw feature dicts into a race-relative matrix (rows = runners)."""
    n = len(raw)
    X = np.zeros((n, len(FEATURE_NAMES)))
    for i, x in enumerate(raw):
        X[i] = [x[f] if x[f] is not None else np.nan for f in FEATURE_NAMES]

    # Price -> log implied probability; unknown prices are treated as rank outsiders.
    odds = X[:, FX["mkt"]]
    known = ~np.isnan(odds) & (odds > 1)
    if known.any():
        odds = np.where(known, odds, odds[known].max() * 1.5)
        X[:, FX["mkt"]] = -np.log(odds)
    else:
        X[:, FX["mkt"]] = 0

    ors = X[:, FX["or_rel"]]
    have = ~np.isnan(ors)
    X[:, FX["or_missing"]] = (~have).astype(float)
    if have.any():
        X[:, FX["or_rel"]] = np.where(have, ors, ors[have].mean()) - ors[have].max()
    else:
        X[:, FX["or_rel"]] = 0

    for f in ("wgt_rel", "age_rel"):
        col = X[:, FX[f]]
        ok = ~np.isnan(col)
        X[:, FX[f]] = np.where(ok, col - col[ok].mean(), 0) if ok.any() else 0
    X = np.nan_to_num(X)
    return X - X.mean(axis=0)  # only differences within a race matter


def race_kind(text):
    return "jumps" if re.search(r"hurdle|chase|nh flat|bumper|national hunt", text or "", re.I) else "flat"


# --- building the training set from the form file -----------------------------------

def _last_date(path):
    with open(path, "rb") as f:
        f.seek(max(0, os.path.getsize(path) - 4096))
        lines = f.read().decode("utf-8", "ignore").strip().splitlines()
    return lines[-1][:10]


def _lines_from(f, since):
    """The open form file's lines from the first run dated `since` or later (the file is in date
    order), header kept. Skipping on the raw text avoids CSV-parsing the years that aren't wanted;
    the regex keeps a wrapped comment line from being taken for a dated row."""
    header = next(f)
    dated = re.compile(r"\d{4}-\d\d-\d\d,")
    rest = itertools.dropwhile(lambda line: line[:10] < since or not dated.match(line), f)
    return itertools.chain([header], rest)


def build_dataset(form_path, on_progress=None, stop=None, years=None):
    """Stream the form file oldest first, emitting one feature matrix per race.

    With `years`, only that many years before the file's last date are read; the first year of
    those just builds up horse histories and strike rates, so races are emitted after it.

    Returns (races, horses, trainers, jockeys, last_date) where races is a list of
    (day_str, kind, X, winner_vector) and the rest is the state as of the end of the file.
    """
    horses, trainers, jockeys = {}, StrikeRate(), StrikeRate()
    races = []
    day_conn = []  # (trainer, jockey, won) for the current day; added once the day is over
    first = last = None
    end = _last_date(form_path)
    since, train_from = None, TRAIN_FROM
    if years:
        start = ordinal(end) - round(365.25 * years)
        since = date.fromordinal(start).isoformat()
        train_from = max(TRAIN_FROM, date.fromordinal(start + WARM_UP_DAYS).isoformat())
    span = None
    cur_id, rows = None, []

    def flush_race(rows):
        r0 = rows[0]
        day = ordinal(r0["date"])
        race = {"day": day, "course": norm_course(r0["course"]), "dist": furlongs(r0["dist"]),
                "going": going_code(r0["going"]), "cls": race_class(r0["class"])}
        emit = r0["date"] >= train_from
        raw, won = [], []
        updates = []
        for r in rows:
            key = (norm_name(r["horse"]), int(r["date"][:4]) - int(r["age"] or 0))
            h = horses.get(key)
            pos = r["pos"].strip().upper()
            if emit:
                hg = r["hg"].strip()
                run = {"or_": to_float(r["or"]), "wgt": pounds(r["wgt"]), "age": to_float(r["age"]),
                       "odds": decimal_odds(r["sp"]),
                       "hg_first": bool(hg) and h is not None and h.runs > 0 and not h.last_hg,
                       "trainer": norm_person(r["trainer"]), "jockey": norm_person(r["jockey"])}
                raw.append(runner_features(h, race, run, trainers, jockeys))
                won.append(1.0 if pos == "1" else 0.0)
            updates.append((key, r, pos))
            day_conn.append((norm_person(r["trainer"]), norm_person(r["jockey"]), pos == "1"))
        ran = int(to_float(rows[0]["ran"]) or len(rows))
        for key, r, pos in updates:
            h = horses.get(key)
            if h is None:
                h = horses[key] = Horse()
            h.add_run(race["day"], race["course"], race["dist"], race["going"], race["cls"],
                      pos, ran, r["comment"], r["hg"].strip())
        if emit and len(raw) >= 2 and sum(won) > 0:
            y = np.array(won) / sum(won)  # dead heats share the win
            races.append((r0["date"], race_kind(r0["type"] + " " + r0["race_name"]), race_matrix(raw), y))

    with open(form_path, newline="", encoding="utf-8") as f:
        for i, r in enumerate(csv.DictReader(_lines_from(f, since) if since else f)):
            if r["date"] != last:
                if day_conn:  # previous day's racing is over: count it for strike rates
                    d = ordinal(last)
                    for t, j, w in day_conn:
                        trainers.add(t, d, w)
                        jockeys.add(j, d, w)
                    day_conn.clear()
                if first is None:
                    first = r["date"]
                    span = max(ordinal(end) - ordinal(first), 1)
                last = r["date"]
                if stop and stop.is_set():
                    raise InterruptedError("stopped")
                if on_progress:
                    on_progress((ordinal(last) - ordinal(first)) / span, f"Reading form: {last}")
            if r["race_id"] != cur_id:
                if rows:
                    flush_race(rows)
                cur_id, rows = r["race_id"], []
            rows.append(r)
        if rows:
            flush_race(rows)
    d = ordinal(last)
    for t, j, w in day_conn:
        trainers.add(t, d, w)
        jockeys.add(j, d, w)
    return races, horses, trainers, jockeys, last


# --- conditional logit -------------------------------------------------------------

def _stack(races, cols):
    X = np.vstack([r[2][:, cols] for r in races])
    y = np.concatenate([r[3] for r in races])
    sizes = np.array([len(r[3]) for r in races])
    starts = np.concatenate([[0], np.cumsum(sizes)[:-1]])
    return X, y, sizes, starts


def _probs(Z, w, sizes, starts):
    s = Z @ w
    s -= np.repeat(np.maximum.reduceat(s, starts), sizes)
    e = np.exp(s)
    return e / np.repeat(np.add.reduceat(e, starts), sizes)


def fit(races, cols, iters=25):
    """Newton-Raphson for a conditional (multinomial) logit with one winner per race."""
    X, y, sizes, starts = _stack(races, cols)
    mu, sd = X.mean(axis=0), X.std(axis=0)
    sd[sd == 0] = 1
    Z = (X - mu) / sd
    w = np.zeros(Z.shape[1])
    for _ in range(iters):
        p = _probs(Z, w, sizes, starts)
        g = Z.T @ (y - p) - RIDGE * w
        M = np.add.reduceat(p[:, None] * Z, starts)
        H = Z.T @ (p[:, None] * Z) - M.T @ M + RIDGE * np.eye(len(w))
        step = np.linalg.solve(H, g)
        w += step
        if np.abs(step).max() < 1e-6:
            break
    return {"cols": cols, "mu": mu, "sd": sd, "w": w}


def predict(model, X):
    Z = (X[:, model["cols"]] - model["mu"]) / model["sd"]
    s = Z @ model["w"]
    e = np.exp(s - s.max())
    return e / e.sum()


def contributions(model, X):
    """Per-runner, per-feature push on the win score relative to the field average."""
    Z = (X[:, model["cols"]] - model["mu"]) / model["sd"]
    C = Z * model["w"]
    return C - C.mean(axis=0)


def evaluate(model, races):
    """Top-pick strike rate, mean log-likelihood of the winner, and the market favourite's strike rate."""
    picks = favs = 0
    ll = 0.0
    for _, _, X, y in races:
        p = predict(model, X)
        picks += y[p.argmax()] > 0
        favs += y[X[:, FX["mkt"]].argmax()] > 0
        ll += math.log(max(float(p @ y), 1e-12))
    n = len(races)
    return {"races": n, "top_pick": picks / n, "favourite": favs / n, "loglik": ll / n}


def train(form_path, on_progress=None, stop=None, years=None):
    races, horses, trainers, jockeys, last = build_dataset(form_path, on_progress, stop, years)
    models, stats = {}, {}
    for kind in ("flat", "jumps"):
        kr = [r for r in races if r[1] == kind]
        tr = [r for r in kr if r[0] < HOLDOUT_FROM]
        ho = [r for r in kr if r[0] >= HOLDOUT_FROM]
        for name, cols in (("form", FORM_ONLY), ("market", ALL_FEATURES)):
            if on_progress:
                on_progress(1.0, f"Fitting {kind} {name} model…")
            if ho:
                stats[(kind, name)] = evaluate(fit(tr, cols), ho)
            models[(kind, name)] = fit(kr, cols)  # final model uses everything
            log.info("%s/%s: %s", kind, name, stats.get((kind, name)))
    return {"version": MODEL_VERSION, "models": models, "stats": stats, "horses": horses,
            "trainers": trainers, "jockeys": jockeys, "form_last": last,
            "n_races": len(races), "holdout_from": HOLDOUT_FROM}


def cache_path(form_path, out_dir):
    return Path(out_dir) / f"winners_model_{Path(form_path).stem}.pkl"


def load_or_train(form_path, out_dir, rebuild=False, on_progress=None, stop=None, years=None):
    """Load the cached model for this form file, or build it (a couple of minutes) and cache it.
    `years` limits training to the file's last few years (None: all of it)."""
    st = os.stat(form_path)
    sig = (MODEL_VERSION, st.st_size, int(st.st_mtime)) + ((years,) if years else ())
    path = cache_path(form_path, out_dir)
    if path.exists() and not rebuild:
        with open(path, "rb") as f:
            m = pickle.load(f)
        if m.get("sig") == sig:
            return m
        log.info("form file changed; rebuilding model")
    m = train(form_path, on_progress, stop, years)
    m["sig"] = sig
    Path(out_dir).mkdir(parents=True, exist_ok=True)
    with open(path, "wb") as f:
        pickle.dump(m, f, protocol=pickle.HIGHEST_PROTOCOL)
    log.info("model cached in %s", path)
    return m


# --- predicting a card ------------------------------------------------------------

def card_odds(u):
    for v in (u.get("best_odds_decimal"), u.get("odds"), u.get("forecast_odds")):
        d = decimal_odds(v)
        if d and d > 1:
            return d
    return None


def find_horse(horses, name, year, age):
    key = norm_name(name)
    try:
        by = year - int(age)
    except (TypeError, ValueError):
        return None
    for b in (by, by - 1, by + 1):
        h = horses.get((key, b))
        if h is not None:
            return h
    return None


def card_horse(model, u, day, year):
    """Form-file history for a card runner, topped up with the card's own recent runs."""
    known = find_horse(model["horses"], u["horse"], year, u.get("horse_age"))
    h = Horse()
    if known is not None:
        h.runs, h.wins, h.places, h.last_hg = known.runs, known.wins, known.places, known.last_hg
        h.recent, h.win_spots = list(known.recent), list(known.win_spots)
    since = h.last_day or 0
    for i in range(RECENT, 0, -1):  # oldest first
        d = u.get(f"last{i}_date")
        if not d or ordinal(d) <= since or ordinal(d) >= day:
            continue
        h.add_run(ordinal(d), norm_course(u.get(f"last{i}_course")), furlongs(u.get(f"last{i}_dist")),
                  going_code(u.get(f"last{i}_going")), race_class(u.get(f"last{i}_class")),
                  u.get(f"last{i}_pos"), to_float(u.get(f"last{i}_ran")), u.get(f"last{i}_comment"))
    # The card's career totals cover runs the form file may not have (abroad, after it ends).
    runs, wins, placed = (int(to_float(u.get(k)) or 0) for k in ("runs", "wins", "placed"))
    if runs > h.runs:
        h.runs, h.wins, h.places = runs, max(wins, h.wins), max(placed, h.places)
    return h, known is not None


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def runners_path_for(races_path):
    """data/cards_runners_<date>.csv next to the races file or in data/, matching its date."""
    rows = read_csv(races_path)
    if not rows:
        return None
    d = rows[0].get("date")
    p = Path(races_path)
    for c in (p.with_name(p.name.replace("races", "runners")), p.parent / f"cards_runners_{d}.csv",
              p.parent / "data" / f"cards_runners_{d}.csv"):
        if c.exists() and c != p:
            return c
    return None


def predict_card(model, races_path, runners_path):
    """Return a list of race dicts, each with 'runners' sorted by form+market win probability."""
    runners = {}
    for u in read_csv(runners_path):
        runners.setdefault(u["race_id"], []).append(u)
    out = []
    for rc in read_csv(races_path):
        field = [u for u in runners.get(rc["race_id"], []) if u.get("status", "RUNNER") != "NONRUNNER"]
        if not field:
            continue
        day = ordinal(rc["date"])
        year = int(rc["date"][:4])
        race = {"day": day, "course": norm_course(rc.get("rp_course") or rc["course"]),
                "dist": furlongs(rc.get("rp_dist") or rc.get("distance")),
                "going": going_code(rc.get("going")), "cls": race_class(rc.get("race_class"))}
        kind = race_kind(" ".join(rc.get(k) or "" for k in ("rp_type", "race_name")))
        raw, found = [], []
        for u in field:
            h, known = card_horse(model, u, day, year)
            run = {"or_": to_float(u.get("official_rating")), "wgt": pounds(u.get("weight")),
                   "age": to_float(u.get("horse_age")), "odds": card_odds(u),
                   "hg_first": bool(u.get("headgear_first_time")),
                   "trainer": norm_person(u.get("trainer")), "jockey": norm_person(u.get("jockey"))}
            raw.append(runner_features(h if h.recent else None, race, run,
                                       model["trainers"], model["jockeys"]))
            found.append((h, known))
        X = race_matrix(raw)
        mm, fm = model["models"][(kind, "market")], model["models"][(kind, "form")]
        pm, pf = predict(mm, X), predict(fm, X)
        cm, cf = contributions(mm, X), contributions(fm, X)
        rows = []
        for i, u in enumerate(field):
            h, known = found[i]
            last = h.recent[0] if h.recent else None
            rows.append({
                **u, "p_market": float(pm[i]), "p_form": float(pf[i]),
                "price": card_odds(u), "in_form_file": known,
                "last_clues": ", ".join(k for k, v in zip(CLUE_NAMES, last[6]) if v) if last else "",
                "last_comment": last[7] if last else "",
                "reasons_market": _reasons(mm, cm[i], X[i]), "reasons_form": _reasons(fm, cf[i], X[i]),
            })
        rows.sort(key=lambda r: -r["p_market"])
        rank_f = sorted(range(len(rows)), key=lambda i: -rows[i]["p_form"])
        for n, i in enumerate(rank_f, 1):
            rows[i]["form_rank"] = n
        out.append({**rc, "kind": kind, "runners": rows,
                    "form_pick": rows[rank_f[0]]["horse"], "form_pick_p": rows[rank_f[0]]["p_form"]})
    out.sort(key=lambda r: (r["time"], r["course"]))
    return out


YES_NO = {"debut", "won_last", "nf_last", "long_abs", "course_win", "dist_win", "cd_win", "going_win",
          "hg_first", "or_missing", "c_trouble", "c_finish", "c_weaken", "c_easy", "c_green",
          "c_trouble_beaten", "c_finish_beaten"}


def _reasons(model, contrib, x):
    """[(label, push)] sorted strongest first; x is the runner's race-relative feature row.

    A yes/no clue the horse lacks while others in the field have it reads 'not <clue>'.
    """
    out = []
    for c, v in zip(model["cols"], contrib):
        if abs(v) < 0.05:
            continue
        name = FEATURE_NAMES[c]
        label = LABELS[name]
        if name in YES_NO and x[c] < 0:
            label = "not " + label
        out.append((label, float(v)))
    return sorted(out, key=lambda p: -abs(p[1]))


def fair_odds(p):
    """Win probability -> decimal odds string, e.g. 0.25 -> '4.00'."""
    if p <= 0:
        return ""
    d = 1 / p
    return f"{d:.2f}" if d < 10 else f"{d:.1f}" if d < 100 else f"{d:.0f}"


# --- CLI ---------------------------------------------------------------------------

def parse_args(argv):
    p = argparse.ArgumentParser(description="Find a day's probable winners from form")
    p.add_argument("--form", type=Path, default=Path("sample_form.csv"), help="past form CSV")
    p.add_argument("--races", type=Path, default=Path("sample.csv"), help="cards_races CSV for the day")
    p.add_argument("--runners", type=Path, help="cards_runners CSV (default: found from --races' date)")
    p.add_argument("--out", type=Path, default=Path("data"), help="where the model cache lives")
    p.add_argument("--rebuild", action="store_true", help="rebuild the model from the form file")
    p.add_argument("--csv", type=Path, help="also write picks to this CSV")
    p.add_argument("-v", "--verbose", action="store_true")
    return p.parse_args(argv)


PICK_FIELDS = ["date", "time", "course", "race_name", "kind", "runners_n", "pick", "pick_p", "pick_fair",
               "pick_price", "second", "second_p", "form_pick", "form_pick_p", "spotlight"]


def picks_rows(cards):
    for rc in cards:
        r = rc["runners"]
        yield {"date": rc["date"], "time": rc["time"], "course": rc["course"], "race_name": rc["race_name"],
               "kind": rc["kind"], "runners_n": len(r), "pick": r[0]["horse"],
               "pick_p": f"{r[0]['p_market']:.3f}", "pick_fair": fair_odds(r[0]["p_market"]),
               "pick_price": r[0]["price"] or "", "second": r[1]["horse"] if len(r) > 1 else "",
               "second_p": f"{r[1]['p_market']:.3f}" if len(r) > 1 else "",
               "form_pick": rc["form_pick"], "form_pick_p": f"{rc['form_pick_p']:.3f}",
               "spotlight": rc.get("verdict_1st", "")}


def write_picks(cards, path):
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, PICK_FIELDS)
        w.writeheader()
        w.writerows(picks_rows(cards))


def main(argv=None):
    a = parse_args(argv)
    logging.basicConfig(level=logging.DEBUG if a.verbose else logging.INFO,
                        format="%(asctime)s %(levelname)s %(message)s", datefmt="%H:%M:%S")
    runners = a.runners or runners_path_for(a.races)
    if not runners:
        sys.exit("no runners file found; pass --runners data/cards_runners_<date>.csv")
    last_shown = [-1]

    def progress(frac, msg):
        pct = int(frac * 100)
        if pct // 10 != last_shown[0] // 10:
            last_shown[0] = pct
            log.info("%s (%d%%)", msg, pct)

    model = load_or_train(a.form, a.out, a.rebuild, progress)
    for (kind, name), s in sorted(model["stats"].items()):
        log.info("holdout %s/%s: %d races, top pick won %.1f%% (favourite %.1f%%)",
                 kind, name, s["races"], 100 * s["top_pick"], 100 * s["favourite"])
    cards = predict_card(model, a.races, runners)
    for rc in cards:
        r = rc["runners"]
        print(f"{rc['time']} {rc['course']:<10} {r[0]['horse']:<22} {100 * r[0]['p_market']:4.0f}%  "
              f"(form only: {rc['form_pick']} {100 * rc['form_pick_p']:.0f}%)")
    if a.csv:
        write_picks(cards, a.csv)
        log.info("wrote %s", a.csv)


if __name__ == "__main__":
    # Run as the imported module so the cached model pickles Horse as form_model.Horse, not
    # __main__.Horse, and the GUI can load it.
    import form_model
    sys.exit(form_model.main())
