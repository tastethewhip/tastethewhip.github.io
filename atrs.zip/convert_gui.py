#!/usr/bin/env python3
"""Tkinter tab for viewing and converting between CSV, SQLite and Parquet.

Files are streamed in batches, so large files (e.g. raceform.csv/.db) can be
converted without loading them into memory. Needs pyarrow for Parquet/CSV.
"""
import csv
import os
import queue
import sqlite3
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

import pyarrow as pa
import pyarrow.compute as pc
import pyarrow.csv as pacsv
import pyarrow.parquet as pq

FORMATS = ("CSV", "SQLite", "Parquet")
EXTENSIONS = {
    "CSV": (".csv", ".tsv", ".txt"),
    "SQLite": (".db", ".sqlite", ".sqlite3", ".db3"),
    "Parquet": (".parquet", ".pq"),
}
FILETYPES = [
    ("All supported", " ".join(f"*{e}" for exts in EXTENSIONS.values() for e in exts)),
    ("CSV", "*.csv *.tsv *.txt"),
    ("SQLite", "*.db *.sqlite *.sqlite3 *.db3"),
    ("Parquet", "*.parquet *.pq"),
    ("All files", "*"),
]
BATCH_ROWS = 50_000


class Cancelled(Exception):
    pass


def detect_format(path):
    ext = Path(path).suffix.lower()
    for fmt, exts in EXTENSIONS.items():
        if ext in exts:
            return fmt
    try:
        with open(path, "rb") as f:
            head = f.read(16)
    except OSError:
        return "CSV"
    if head.startswith(b"SQLite format 3\0"):
        return "SQLite"
    if head.startswith(b"PAR1"):
        return "Parquet"
    return "CSV"


def qident(name):
    return '"' + name.replace('"', '""') + '"'


def sqlite_tables(path):
    with sqlite3.connect(f"file:{path}?mode=ro", uri=True) as conn:
        return [r[0] for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type IN ('table', 'view') "
            "AND name NOT LIKE 'sqlite_%' ORDER BY name")]


def csv_delimiter(path):
    return "\t" if Path(path).suffix.lower() == ".tsv" else ","


# ---------- preview ----------

def preview(path, fmt, table, limit):
    """Return (columns [(name, type)], rows) for the first `limit` rows."""
    if fmt == "CSV":
        with open(path, newline="", encoding="utf-8-sig", errors="replace") as f:
            reader = csv.reader(f, delimiter=csv_delimiter(path))
            header = next(reader, [])
            rows = []
            for row in reader:
                if len(rows) >= limit:
                    break
                rows.append(row)
        return [(h, "text") for h in header], rows
    if fmt == "SQLite":
        with sqlite3.connect(f"file:{path}?mode=ro", uri=True) as conn:
            cols = [(r[1], r[2] or "") for r in conn.execute(f"PRAGMA table_info({qident(table)})")]
            rows = conn.execute(f"SELECT * FROM {qident(table)} LIMIT ?", (limit,)).fetchall()
        return cols, rows
    pf = pq.ParquetFile(path)
    cols = [(f.name, str(f.type)) for f in pf.schema_arrow]
    rows = []
    for batch in pf.iter_batches(batch_size=max(limit, 1)):
        rows = list(zip(*(c.to_pylist() for c in batch.columns)))[:limit]
        break
    return cols, rows


def count_rows(path, fmt, table):
    if fmt == "Parquet":
        return pq.ParquetFile(path).metadata.num_rows
    if fmt == "SQLite":
        with sqlite3.connect(f"file:{path}?mode=ro", uri=True) as conn:
            return conn.execute(f"SELECT COUNT(*) FROM {qident(table)}").fetchone()[0]
    # Only parse the first column, as text, so type inference can't fail.
    first = pacsv.open_csv(path, parse_options=pacsv.ParseOptions(delimiter=csv_delimiter(path))).schema.names[0]
    reader = pacsv.open_csv(
        path,
        parse_options=pacsv.ParseOptions(delimiter=csv_delimiter(path)),
        convert_options=pacsv.ConvertOptions(include_columns=[first], column_types={first: pa.string()}),
    )
    return sum(b.num_rows for b in reader)


# ---------- readers: each yields a schema, then RecordBatches ----------

def read_csv(path, detect_types, status, check):
    parse = pacsv.ParseOptions(delimiter=csv_delimiter(path))
    names = pacsv.open_csv(path, parse_options=parse).schema.names
    if detect_types:
        # Pass 1: read everything as text and narrow each column to the
        # tightest type every value fits (int64 -> float64 -> string).
        status("Scanning CSV column types…")
        types = {n: pa.int64() for n in names}
        seen = {n: False for n in names}
        reader = pacsv.open_csv(path, parse_options=parse, convert_options=pacsv.ConvertOptions(
            column_types={n: pa.string() for n in names}, strings_can_be_null=True))
        for batch in reader:
            check()
            for name, col in zip(names, batch.columns):
                if col.null_count == len(col):
                    continue
                seen[name] = True
                while types[name] != pa.string():
                    try:
                        pc.cast(col, types[name])
                        break
                    except (pa.ArrowInvalid, pa.ArrowNotImplementedError):
                        types[name] = pa.float64() if types[name] == pa.int64() else pa.string()
        types = {n: (t if seen[n] else pa.string()) for n, t in types.items()}
    else:
        types = {n: pa.string() for n in names}
    reader = pacsv.open_csv(path, parse_options=parse, convert_options=pacsv.ConvertOptions(column_types=types))
    yield reader.schema
    yield from reader


def read_sqlite(path, table, status, check):
    conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
    try:
        names = [r[1] for r in conn.execute(f"PRAGMA table_info({qident(table)})")]
        # SQLite columns can hold mixed types, so check what is actually stored.
        status("Scanning SQLite column types…")
        exprs = []
        for n in names:
            exprs += [f"max(typeof({qident(n)}) = '{t}')" for t in ("text", "blob", "real", "integer")]
        flags = conn.execute(f"SELECT {', '.join(exprs)} FROM {qident(table)}").fetchone()
        types = []
        for i in range(len(names)):
            has_text, has_blob, has_real, has_int = flags[i * 4:i * 4 + 4]
            if has_text or (has_blob and (has_real or has_int)):
                types.append(pa.string())
            elif has_blob:
                types.append(pa.binary())
            elif has_real:
                types.append(pa.float64())
            elif has_int:
                types.append(pa.int64())
            else:
                types.append(pa.string())
        schema = pa.schema(list(zip(names, types)))
        yield schema
        cur = conn.execute(f"SELECT * FROM {qident(table)}")
        while rows := cur.fetchmany(BATCH_ROWS):
            check()
            arrays = []
            for t, values in zip(types, zip(*rows)):
                if t == pa.string():
                    values = [v if v is None or isinstance(v, str) else
                              (v.decode("utf-8", "replace") if isinstance(v, bytes) else str(v)) for v in values]
                arrays.append(pa.array(values, type=t))
            yield pa.RecordBatch.from_arrays(arrays, schema=schema)
    finally:
        conn.close()


def read_parquet(path, check):
    pf = pq.ParquetFile(path)
    yield pf.schema_arrow
    for batch in pf.iter_batches(batch_size=BATCH_ROWS):
        check()
        yield batch


# ---------- writers ----------

def sqlite_type(t):
    if pa.types.is_integer(t) or pa.types.is_boolean(t):
        return "INTEGER"
    if pa.types.is_floating(t):
        return "REAL"
    if pa.types.is_binary(t) or pa.types.is_large_binary(t):
        return "BLOB"
    return "TEXT"


def sqlite_values(col):
    """Python values sqlite3 can store natively; anything else becomes text."""
    t = col.type
    values = col.to_pylist()
    if (pa.types.is_integer(t) or pa.types.is_floating(t) or pa.types.is_boolean(t)
            or pa.types.is_string(t) or pa.types.is_large_string(t)
            or pa.types.is_binary(t) or pa.types.is_large_binary(t)):
        return values
    if pa.types.is_temporal(t):
        return [None if v is None else v.isoformat() if hasattr(v, "isoformat") else str(v) for v in values]
    return [None if v is None else str(v) for v in values]


def write(batches, out_path, out_fmt, out_table, progress):
    schema = next(batches)
    done = 0
    if out_fmt == "SQLite":
        conn = sqlite3.connect(out_path, isolation_level=None)
        try:
            conn.execute("BEGIN")
            conn.execute(f"DROP TABLE IF EXISTS {qident(out_table)}")
            cols = ", ".join(f"{qident(f.name)} {sqlite_type(f.type)}" for f in schema)
            conn.execute(f"CREATE TABLE {qident(out_table)} ({cols})")
            insert = f"INSERT INTO {qident(out_table)} VALUES ({', '.join('?' * len(schema))})"
            for batch in batches:
                conn.executemany(insert, zip(*(sqlite_values(c) for c in batch.columns)))
                done += batch.num_rows
                progress(done)
            conn.execute("COMMIT")
        except BaseException:
            if conn.in_transaction:
                conn.execute("ROLLBACK")
            raise
        finally:
            conn.close()
    elif out_fmt == "Parquet":
        with pq.ParquetWriter(out_path, schema, compression="snappy") as w:
            for batch in batches:
                w.write_batch(batch)
                done += batch.num_rows
                progress(done)
    else:
        opts = pacsv.WriteOptions(delimiter=csv_delimiter(out_path))
        with pacsv.CSVWriter(out_path, schema, write_options=opts) as w:
            for batch in batches:
                w.write_batch(batch)
                done += batch.num_rows
                progress(done)
    return done


class ConvertFrame(ttk.Frame):
    def __init__(self, master):
        super().__init__(master)
        self.q = queue.Queue()
        self.cancel_event = threading.Event()
        self.worker = None
        self.preview_token = 0

        self.src_var = tk.StringVar()
        self.src_fmt_var = tk.StringVar(value="")
        self.table_var = tk.StringVar()
        self.limit_var = tk.IntVar(value=1000)
        self.info_var = tk.StringVar(value="Choose a CSV, SQLite or Parquet file.")

        self.out_fmt_var = tk.StringVar(value="Parquet")
        self.out_var = tk.StringVar()
        self.out_table_var = tk.StringVar()
        self.detect_var = tk.BooleanVar(value=True)
        self.status_var = tk.StringVar()

        self._build_source()
        self._build_convert()
        self._build_viewer()
        self.after(100, self._poll)

    # ---------- layout ----------

    def _build_source(self):
        f = ttk.LabelFrame(self, text="Source file", padding=8)
        f.pack(fill="x", padx=8, pady=(8, 4))
        f.columnconfigure(1, weight=1)

        ttk.Label(f, text="File").grid(row=0, column=0, sticky="w")
        e = ttk.Entry(f, textvariable=self.src_var)
        e.grid(row=0, column=1, sticky="ew", padx=4)
        e.bind("<Return>", lambda _e: self.set_source(self.src_var.get()))
        ttk.Button(f, text="Browse…", command=self.browse_source).grid(row=0, column=2)
        ttk.Label(f, textvariable=self.src_fmt_var, width=8).grid(row=0, column=3, padx=(8, 0))

        row = ttk.Frame(f)
        row.grid(row=1, column=0, columnspan=4, sticky="w", pady=(6, 0))
        ttk.Label(row, text="Table").pack(side="left")
        self.table_combo = ttk.Combobox(row, textvariable=self.table_var, state="disabled", width=30)
        self.table_combo.pack(side="left", padx=(4, 16))
        self.table_combo.bind("<<ComboboxSelected>>", lambda _e: self._table_changed())
        ttk.Label(row, text="Rows to show").pack(side="left")
        ttk.Spinbox(row, from_=10, to=1_000_000, increment=500, textvariable=self.limit_var,
                    width=9).pack(side="left", padx=(4, 16))
        ttk.Button(row, text="Load preview", command=self.load_preview).pack(side="left")

    def _build_convert(self):
        f = ttk.LabelFrame(self, text="Convert to", padding=8)
        f.pack(fill="x", padx=8, pady=4)
        f.columnconfigure(1, weight=1)

        fmts = ttk.Frame(f)
        fmts.grid(row=0, column=0, columnspan=4, sticky="w")
        for fmt in FORMATS:
            ttk.Radiobutton(fmts, text=fmt, value=fmt, variable=self.out_fmt_var,
                            command=self._out_fmt_changed).pack(side="left", padx=(0, 12))
        self.detect_check = ttk.Checkbutton(fmts, text="Detect CSV column types (otherwise all text)",
                                            variable=self.detect_var)
        self.detect_check.pack(side="left", padx=(12, 0))

        ttk.Label(f, text="Output").grid(row=1, column=0, sticky="w", pady=(6, 0))
        ttk.Entry(f, textvariable=self.out_var).grid(row=1, column=1, sticky="ew", padx=4, pady=(6, 0))
        ttk.Button(f, text="Browse…", command=self.browse_output).grid(row=1, column=2, pady=(6, 0))

        row = ttk.Frame(f)
        row.grid(row=2, column=0, columnspan=4, sticky="ew", pady=(6, 0))
        ttk.Label(row, text="SQLite table").pack(side="left")
        self.out_table_entry = ttk.Entry(row, textvariable=self.out_table_var, width=24)
        self.out_table_entry.pack(side="left", padx=(4, 16))
        self.convert_btn = ttk.Button(row, text="Convert", command=self.start_convert)
        self.convert_btn.pack(side="left")
        self.cancel_btn = ttk.Button(row, text="Cancel", command=self.cancel_event.set, state="disabled")
        self.cancel_btn.pack(side="left", padx=4)
        self.view_out_btn = ttk.Button(row, text="View output", command=self.view_output, state="disabled")
        self.view_out_btn.pack(side="left", padx=4)
        self.progress = ttk.Progressbar(row, mode="indeterminate", length=120)
        self.progress.pack(side="left", padx=(12, 6))
        ttk.Label(row, textvariable=self.status_var).pack(side="left", fill="x", expand=True)
        self._out_fmt_changed()

    def _build_viewer(self):
        ttk.Label(self, textvariable=self.info_var, padding=(8, 2)).pack(fill="x")
        pane = ttk.PanedWindow(self, orient="horizontal")
        pane.pack(fill="both", expand=True, padx=8, pady=(0, 8))

        left = ttk.Frame(pane)
        self.schema_tree = ttk.Treeview(left, columns=("name", "type"), show="headings")
        self.schema_tree.heading("name", text="Column")
        self.schema_tree.heading("type", text="Type")
        self.schema_tree.column("name", width=130)
        self.schema_tree.column("type", width=90)
        sy = ttk.Scrollbar(left, orient="vertical", command=self.schema_tree.yview)
        self.schema_tree.configure(yscrollcommand=sy.set)
        self.schema_tree.pack(side="left", fill="both", expand=True)
        sy.pack(side="right", fill="y")

        right = ttk.Frame(pane)
        right.rowconfigure(0, weight=1)
        right.columnconfigure(0, weight=1)
        self.data_tree = ttk.Treeview(right, show="headings")
        dy = ttk.Scrollbar(right, orient="vertical", command=self.data_tree.yview)
        dx = ttk.Scrollbar(right, orient="horizontal", command=self.data_tree.xview)
        self.data_tree.configure(yscrollcommand=dy.set, xscrollcommand=dx.set)
        self.data_tree.grid(row=0, column=0, sticky="nsew")
        dy.grid(row=0, column=1, sticky="ns")
        dx.grid(row=1, column=0, sticky="ew")

        pane.add(left, weight=1)
        pane.add(right, weight=4)

    # ---------- source ----------

    def browse_source(self):
        path = filedialog.askopenfilename(title="Open data file", filetypes=FILETYPES)
        if path:
            self.set_source(path)

    def set_source(self, path):
        path = path.strip()
        self.src_var.set(path)
        if not os.path.isfile(path):
            messagebox.showerror("Not found", f"File not found:\n{path}")
            return
        fmt = detect_format(path)
        self.src_fmt_var.set(fmt)
        tables = []
        if fmt == "SQLite":
            try:
                tables = sqlite_tables(path)
            except sqlite3.Error as exc:
                messagebox.showerror("SQLite error", str(exc))
                return
            if not tables:
                messagebox.showwarning("No tables", "That database has no tables.")
        self.table_combo.configure(values=tables, state="readonly" if fmt == "SQLite" else "disabled")
        self.table_var.set(tables[0] if tables else "")
        self.detect_check.configure(state="normal" if fmt == "CSV" else "disabled")

        if self.out_fmt_var.get() == fmt:
            self.out_fmt_var.set(next(f for f in FORMATS if f != fmt))
        self._suggest_output()
        self.load_preview()

    def _table_changed(self):
        self._suggest_output()
        self.load_preview()

    def _source_table(self):
        return self.table_var.get() if self.src_fmt_var.get() == "SQLite" else None

    # ---------- output ----------

    def _out_fmt_changed(self):
        self.out_table_entry.configure(state="normal" if self.out_fmt_var.get() == "SQLite" else "disabled")
        self._suggest_output()

    def _suggest_output(self):
        src = self.src_var.get().strip()
        if not src:
            return
        p = Path(src)
        out_fmt = self.out_fmt_var.get()
        table = self._source_table()
        stem = p.stem if not table or out_fmt == "SQLite" else f"{p.stem}_{table}"
        self.out_var.set(str(p.with_name(stem + EXTENSIONS[out_fmt][0])))
        self.out_table_var.set(table or p.stem)

    def browse_output(self):
        fmt = self.out_fmt_var.get()
        exts = EXTENSIONS[fmt]
        current = Path(self.out_var.get()) if self.out_var.get() else None
        path = filedialog.asksaveasfilename(
            title=f"Save {fmt} file", defaultextension=exts[0],
            initialdir=current.parent if current else None,
            initialfile=current.name if current else "",
            filetypes=[(fmt, " ".join(f"*{e}" for e in exts)), ("All files", "*")],
            confirmoverwrite=fmt != "SQLite",  # SQLite adds a table to an existing file
        )
        if path:
            self.out_var.set(path)

    # ---------- preview ----------

    def load_preview(self):
        path = self.src_var.get().strip()
        fmt = self.src_fmt_var.get()
        if not path or not fmt:
            return
        self._show(path, fmt, self._source_table())

    def view_output(self):
        path = self.out_var.get().strip()
        fmt = detect_format(path)
        table = self.out_table_var.get().strip() if fmt == "SQLite" else None
        self._show(path, fmt, table)

    def _show(self, path, fmt, table):
        if fmt == "SQLite" and not table:
            return
        try:
            limit = max(1, int(self.limit_var.get()))
        except (tk.TclError, ValueError):
            limit = 1000
        self.preview_token += 1
        token = self.preview_token
        name = Path(path).name + (f" [{table}]" if table else "")
        self.info_var.set(f"Loading {name}…")

        def work():
            try:
                cols, rows = preview(path, fmt, table, limit)
            except Exception as exc:
                err = exc
                self.q.put(lambda: self._preview_failed(token, name, err))
                return
            self.q.put(lambda: self._fill(token, name, fmt, cols, rows))
            try:
                total = f"{count_rows(path, fmt, table):,}"
            except Exception:
                total = "?"
            self.q.put(lambda: self._set_total(token, name, fmt, len(cols), len(rows), total))

        threading.Thread(target=work, daemon=True).start()

    def _preview_failed(self, token, name, exc):
        if token == self.preview_token:
            self.info_var.set(f"Could not read {name}: {exc}")

    def _fill(self, token, name, fmt, cols, rows):
        if token != self.preview_token:
            return
        self.schema_tree.delete(*self.schema_tree.get_children())
        for c, t in cols:
            self.schema_tree.insert("", "end", values=(c, t))

        tree = self.data_tree
        tree.delete(*tree.get_children())
        ids = [f"c{i}" for i in range(len(cols))]
        tree.configure(columns=ids)
        for cid, (c, _t) in zip(ids, cols):
            tree.heading(cid, text=c, anchor="w")
            tree.column(cid, width=max(70, min(220, len(c) * 9 + 20)), stretch=False, anchor="w")
        for row in rows:
            tree.insert("", "end", values=["" if v is None else v for v in row])
        self._set_total(token, name, fmt, len(cols), len(rows), "counting…")

    def _set_total(self, token, name, fmt, ncols, nrows, total):
        if token == self.preview_token:
            self.info_var.set(f"{name} ({fmt}) — {ncols} columns, {total} rows, showing first {nrows:,}")

    # ---------- convert ----------

    def start_convert(self):
        src = self.src_var.get().strip()
        src_fmt = self.src_fmt_var.get()
        out = self.out_var.get().strip()
        out_fmt = self.out_fmt_var.get()
        table = self._source_table()
        out_table = self.out_table_var.get().strip()

        if not src or not src_fmt:
            messagebox.showwarning("No source", "Choose a source file first.")
            return
        if src_fmt == "SQLite" and not table:
            messagebox.showwarning("No table", "Choose a table to convert.")
            return
        if not out:
            messagebox.showwarning("No output", "Choose an output file.")
            return
        if os.path.exists(out) and os.path.samefile(src, out):
            messagebox.showerror("Same file", "The output file must be different from the source.")
            return
        if out_fmt == "SQLite":
            if not out_table:
                messagebox.showwarning("No table name", "Enter a table name for the SQLite output.")
                return
            if os.path.exists(out):
                try:
                    exists = out_table in sqlite_tables(out)
                except sqlite3.Error as exc:
                    messagebox.showerror("SQLite error", f"{out} is not a usable SQLite file:\n{exc}")
                    return
                if exists and not messagebox.askyesno(
                        "Replace table", f"Table '{out_table}' already exists in {Path(out).name}. Replace it?"):
                    return
        elif os.path.exists(out) and not messagebox.askyesno("Overwrite", f"{out} already exists. Overwrite it?"):
            return

        detect = self.detect_var.get()
        out_existed = os.path.exists(out)
        self.cancel_event.clear()
        self._busy(True)
        self.status_var.set("Starting…")

        def status(msg):
            self.q.put(lambda: self.status_var.set(msg))

        def check():
            if self.cancel_event.is_set():
                raise Cancelled()

        def work():
            try:
                if src_fmt == "CSV":
                    batches = read_csv(src, detect, status, check)
                elif src_fmt == "SQLite":
                    batches = read_sqlite(src, table, status, check)
                else:
                    batches = read_parquet(src, check)
                n = write(batches, out, out_fmt, out_table,
                          lambda done: status(f"Converting… {done:,} rows"))
            except BaseException as exc:
                if not out_existed or out_fmt != "SQLite":
                    try:
                        os.remove(out)
                    except OSError:
                        pass
                err = None if isinstance(exc, Cancelled) else exc
                msg = "Cancelled." if err is None else f"Failed: {err}"
                self.q.put(lambda: self._convert_done(msg, err))
                return
            self.q.put(lambda: self._convert_done(f"Done — {n:,} rows written to {Path(out).name}", None))

        self.worker = threading.Thread(target=work, daemon=True)
        self.worker.start()

    def _convert_done(self, msg, exc):
        self._busy(False)
        self.status_var.set(msg)
        if exc is not None:
            messagebox.showerror("Conversion failed", str(exc))
        elif msg.startswith("Done"):
            self.view_out_btn.configure(state="normal")

    def _busy(self, busy):
        self.convert_btn.configure(state="disabled" if busy else "normal")
        self.cancel_btn.configure(state="normal" if busy else "disabled")
        if busy:
            self.view_out_btn.configure(state="disabled")
            self.progress.start(12)
        else:
            self.progress.stop()

    def _poll(self):
        try:
            while True:
                self.q.get_nowait()()
        except queue.Empty:
            pass
        self.after(100, self._poll)


if __name__ == "__main__":
    root = tk.Tk()
    root.title("CSV / SQLite / Parquet converter")
    root.geometry("1200x750")
    ConvertFrame(root).pack(fill="both", expand=True)
    root.mainloop()
