#!/usr/bin/env python
"""Tkinter front end for form_model: pick a day's racecard and a form file, find the probable winners."""

import logging
import queue
import threading
import tkinter as tk
from datetime import date
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

import form_model as fm
import sl_results

HERE = Path(__file__).resolve().parent
ALL = "All courses"

RACE_COLS = [("time", "Time", 50), ("course", "Course", 100), ("race_name", "Race", 300),
             ("kind", "Type", 50), ("n", "Rnrs", 40), ("pick", "Pick", 150), ("pick_p", "Win %", 50),
             ("pick_fair", "Fair", 50), ("pick_price", "Price", 50), ("result", "Result", 60), ("second", "Next best", 140),
             ("form_pick", "Form-only pick", 140), ("spotlight", "Spotlight pick", 140),
             ("winner", "Winner", 160)]
RUNNER_COLS = [("rank", "#", 30), ("finish", "Fin", 35), ("horse", "Horse", 150), ("p_market", "Win %", 50),
               ("fair", "Fair", 55), ("price", "Price", 50), ("value", "Value", 50),
               ("p_form", "Form %", 50), ("form_rank", "Form #", 50), ("official_rating", "OR", 40),
               ("form", "Form", 70), ("last_ran_days", "Days", 40), ("last_clues", "Last-run clues", 170),
               ("jockey", "Jockey", 120), ("trainer", "Trainer", 120), ("verdict_pick", "Spot", 35)]


class QueueHandler(logging.Handler):
    def __init__(self, q):
        super().__init__()
        self.q = q

    def emit(self, record):
        self.q.put(("log", self.format(record)))


def pct(p):
    return f"{100 * p:.0f}%"


def price_text(d):
    return f"{d:g}" if d else ""


def finish_text(u):
    """Result row -> 'Won', '2nd', '11th', or the casualty code ('PU', 'NR', ...)."""
    pos = u.get("rp_pos") or ""
    if pos == "1":
        return "Won"
    if pos.isdigit():
        n = int(pos)
        return f"{n}{'th' if 10 <= n % 100 <= 20 else {1: 'st', 2: 'nd', 3: 'rd'}.get(n % 10, 'th')}"
    return pos


def finish_tag(u):
    pos = u.get("rp_pos") or ""
    return "won" if pos == "1" else "placed" if pos in ("2", "3") else None if pos == "NR" else "lost"


class WinnersFrame(ttk.Frame):
    def __init__(self, master):
        super().__init__(master)
        self.q = queue.Queue()
        self.stop_event = threading.Event()
        self.model = None
        self.model_form = None  # form file the loaded model came from
        self.cards = []
        self.by_iid = {}
        self.runner_rows = {}

        handler = QueueHandler(self.q)
        handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s", "%H:%M:%S"))
        fm.log.addHandler(handler)
        fm.log.setLevel(logging.INFO)

        self._build_controls()
        self._build_results()
        self._build_log()
        self.after(100, self._poll)

    # --- layout -----------------------------------------------------------

    def _build_controls(self):
        f = ttk.Frame(self, padding=8)
        f.pack(fill="x")
        self.form_var = tk.StringVar(value=str(HERE / "raceform.csv"))
        self.races_var = tk.StringVar(value=str(HERE / "data" / f"cards_races_{date.today()}.csv"))
        self.runners_var = tk.StringVar()
        self._autofill_runners()
        for row, (label, var, cmd) in enumerate((
                ("Form file", self.form_var, None),
                ("Races (cards_races)", self.races_var, self._autofill_runners),
                ("Runners (cards_runners)", self.runners_var, None))):
            ttk.Label(f, text=label).grid(row=row, column=0, sticky="w", pady=2)
            ttk.Entry(f, textvariable=var).grid(row=row, column=1, sticky="ew", padx=4, pady=2)
            ttk.Button(f, text="Browse…", command=lambda v=var, c=cmd: self._pick_file(v, c)
                       ).grid(row=row, column=2, pady=2)
        f.columnconfigure(1, weight=1)

        bar = ttk.Frame(self, padding=(8, 0, 8, 4))
        bar.pack(fill="x")
        self.go_btn = ttk.Button(bar, text="Find winners", command=self._start)
        self.go_btn.pack(side="left")
        self.rebuild_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(bar, text="Rebuild model", variable=self.rebuild_var).pack(side="left", padx=6)
        self.stop_btn = ttk.Button(bar, text="Stop", command=self._stop, state="disabled")
        self.stop_btn.pack(side="left")
        self.export_btn = ttk.Button(bar, text="Export picks…", command=self._export, state="disabled")
        self.export_btn.pack(side="left", padx=4)
        self.check_btn = ttk.Button(bar, text="Check results", command=self._check_results, state="disabled")
        self.check_btn.pack(side="left")
        self.progress = ttk.Progressbar(bar, mode="determinate", maximum=1)
        self.progress.pack(side="left", fill="x", expand=True, padx=8)
        self.status_var = tk.StringVar(value="Ready")
        ttk.Label(bar, textvariable=self.status_var, width=34).pack(side="left")

        flt = ttk.Frame(self, padding=(8, 0, 8, 6))
        flt.pack(fill="x")
        ttk.Label(flt, text="Show").pack(side="left")
        self.course_var = tk.StringVar(value=ALL)
        self.course_cb = ttk.Combobox(flt, textvariable=self.course_var, values=[ALL],
                                      state="readonly", width=22)
        self.course_cb.pack(side="left", padx=6)
        self.course_cb.bind("<<ComboboxSelected>>", lambda e: self._refill_races())
        ttk.Label(flt, text="Rank by").pack(side="left", padx=(16, 4))
        self.rank_var = tk.StringVar(value="market")
        for value, text in (("market", "form + market"), ("form", "form only")):
            ttk.Radiobutton(flt, text=text, value=value, variable=self.rank_var,
                            command=self._refill_races).pack(side="left")
        self.stats_var = tk.StringVar(value="Prices are decimal. Win % comes from a model fitted to the form "
                                           "file; nothing about the day's results is used.")
        ttk.Label(self, textvariable=self.stats_var, foreground="grey", padding=(8, 0, 8, 6)).pack(fill="x")
        self.results_var = tk.StringVar()
        ttk.Label(self, textvariable=self.results_var, padding=(8, 0, 8, 6)).pack(fill="x")

    def _tree(self, parent, cols, stretch):
        frame = ttk.Frame(parent)
        tree = ttk.Treeview(frame, columns=[c for c, _, _ in cols], show="headings", selectmode="browse")
        for key, title, width in cols:
            tree.heading(key, text=title, command=lambda k=key, t=tree: self._sort(t, k, False))
            tree.column(key, width=width, stretch=key in stretch)
        ys = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        xs = ttk.Scrollbar(frame, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=ys.set, xscrollcommand=xs.set)
        tree.grid(row=0, column=0, sticky="nsew")
        ys.grid(row=0, column=1, sticky="ns")
        xs.grid(row=1, column=0, sticky="ew")
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)
        return frame, tree

    def _build_results(self):
        pane = ttk.PanedWindow(self, orient="vertical")
        pane.pack(fill="both", expand=True, padx=8)
        rf, self.race_tree = self._tree(pane, RACE_COLS, ("race_name",))
        lower = ttk.PanedWindow(pane, orient="horizontal")
        uf, self.runner_tree = self._tree(lower, RUNNER_COLS, ("horse", "last_clues"))
        df = ttk.Frame(lower)
        self.detail = tk.Text(df, wrap="word", state="disabled", width=50)
        ys = ttk.Scrollbar(df, orient="vertical", command=self.detail.yview)
        self.detail.configure(yscrollcommand=ys.set)
        self.detail.pack(side="left", fill="both", expand=True)
        ys.pack(side="left", fill="y")
        self.detail.tag_configure("h", font=("TkDefaultFont", 10, "bold"))
        self.detail.tag_configure("up", foreground="#1a7f37")
        self.detail.tag_configure("down", foreground="#c62828")
        self.detail.tag_configure("note", foreground="grey")
        lower.add(uf, weight=3)
        lower.add(df, weight=2)
        pane.add(rf, weight=2)
        pane.add(lower, weight=3)
        self.race_tree.tag_configure("value", foreground="#1a7f37")
        for tree in (self.race_tree, self.runner_tree):
            tree.tag_configure("won", background="#c8efd0")
            tree.tag_configure("placed", background="#fff1b8")
            tree.tag_configure("lost", background="#f6d5d8")
        self.runner_tree.tag_configure("value", foreground="#1a7f37")
        self.runner_tree.tag_configure("top", font=("TkDefaultFont", 9, "bold"))
        self.race_tree.bind("<<TreeviewSelect>>", self._show_race)
        self.runner_tree.bind("<<TreeviewSelect>>", self._show_runner)

    def _build_log(self):
        f = ttk.Frame(self, padding=8)
        f.pack(fill="x")
        self.log_text = tk.Text(f, height=5, state="disabled", wrap="none")
        ys = ttk.Scrollbar(f, orient="vertical", command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=ys.set)
        self.log_text.pack(side="left", fill="x", expand=True)
        ys.pack(side="left", fill="y")

    # --- actions ----------------------------------------------------------

    def _pick_file(self, var, then=None):
        cur = Path(var.get() or HERE)
        p = filedialog.askopenfilename(initialdir=cur.parent if cur.suffix else cur,
                                       filetypes=[("CSV files", "*.csv"), ("All files", "*")])
        if p:
            var.set(p)
            if then:
                then()

    def _autofill_runners(self):
        try:
            found = fm.runners_path_for(self.races_var.get())
        except (OSError, KeyError):
            found = None
        if found:
            self.runners_var.set(str(found))

    def _start(self):
        paths = [Path(v.get()) for v in (self.form_var, self.races_var, self.runners_var)]
        missing = [str(p) for p in paths if not p.is_file()]
        if missing:
            messagebox.showerror("Missing file", "Can't find:\n" + "\n".join(missing))
            return
        models = [str(p) for p in paths if p.suffix == ".pkl"]
        if models:
            messagebox.showerror("Model file selected",
                                 "These are cached model files, not CSVs:\n" + "\n".join(models) +
                                 "\n\nPick the form CSV (e.g. raceform.csv); the model is loaded from it "
                                 "automatically.")
            return
        self.stop_event.clear()
        self.go_btn.configure(state="disabled")
        self.stop_btn.configure(state="normal")
        self.export_btn.configure(state="disabled")
        self.check_btn.configure(state="disabled")
        self.progress.configure(value=0)
        self.status_var.set("Loading model…")
        threading.Thread(target=self._run, args=(*paths, self.rebuild_var.get()), daemon=True).start()

    def _run(self, form, races, runners, rebuild):
        try:
            model = self.model
            if rebuild or model is None or self.model_form != form:
                model = fm.load_or_train(form, HERE / "data", rebuild, stop=self.stop_event,
                                         on_progress=lambda f, msg: self.q.put(("progress", (f, msg))))
            self.q.put(("done", (model, form, fm.predict_card(model, races, runners))))
        except InterruptedError:
            self.q.put(("error", None))
        except Exception as e:  # surface anything unexpected in the GUI
            self.q.put(("error", f"{type(e).__name__}: {e}"))

    def _stop(self):
        self.stop_event.set()
        self.stop_btn.configure(state="disabled")
        self.status_var.set("Stopping…")

    def _export(self):
        day = self.cards[0]["date"] if self.cards else "day"
        p = filedialog.asksaveasfilename(initialdir=HERE / "data", initialfile=f"picks_{day}.csv",
                                         defaultextension=".csv", filetypes=[("CSV files", "*.csv")])
        if p:
            fm.write_picks(self.cards, p)
            self._log(f"wrote {p}")

    def _check_results(self):
        wanted = {}
        for rc in self.cards:
            wanted.setdefault(rc["date"], set()).add(str(rc["race_id"]))
        self.stop_event.clear()
        self.go_btn.configure(state="disabled")
        self.check_btn.configure(state="disabled")
        self.stop_btn.configure(state="normal")
        self.progress.configure(value=0)
        self.status_var.set("Checking results…")
        threading.Thread(target=self._fetch_results, args=(wanted,), daemon=True).start()

    def _fetch_results(self, wanted):
        """Fetch results for the card's races that have been run; unfinished races are skipped."""
        try:
            client = sl_results.Client()
            raw_dir = HERE / "data" / "raw"
            out = {}
            for day, ids in sorted(wanted.items()):
                todo = [(ms, rs) for ms, rs in sl_results.day_races(client, date.fromisoformat(day), False)
                        if str(rs["race_summary_reference"]["id"]) in ids]
                for n, (ms, rs) in enumerate(todo, 1):
                    if self.stop_event.is_set():
                        raise InterruptedError
                    self.q.put(("progress", (n / len(todo), f"Results {day}: {n}/{len(todo)}")))
                    rid, stage = str(rs["race_summary_reference"]["id"]), rs.get("race_stage")
                    out[rid] = {"stage": stage}
                    if stage in sl_results.FINAL_STAGES and stage != "ABANDONED":
                        race = sl_results.fetch_race(client, raw_dir, ms, rs, refresh=False)
                        if race:
                            out[rid]["runners"] = list(sl_results.runner_rows(race))
            self.q.put(("results", out))
        except InterruptedError:
            self.q.put(("error", None))
        except Exception as e:  # surface anything unexpected in the GUI
            self.q.put(("error", f"{type(e).__name__}: {e}"))

    # --- queue ------------------------------------------------------------

    def _poll(self):
        try:
            while True:
                kind, data = self.q.get_nowait()
                if kind == "log":
                    self._log(data)
                elif kind == "progress":
                    frac, msg = data
                    self.progress.configure(value=frac)
                    self.status_var.set(msg)
                elif kind == "done":
                    self.model, self.model_form, self.cards = data
                    self._show_stats()
                    self._done(f"{len(self.cards)} races")
                elif kind == "results":
                    self._attach_results(data)
                elif kind == "error":
                    self._done("Stopped" if data is None else "Failed")
                    if data:
                        messagebox.showerror("Error", data)
        except queue.Empty:
            pass
        self.after(100, self._poll)

    def _done(self, status):
        self.go_btn.configure(state="normal")
        self.stop_btn.configure(state="disabled")
        self.progress.configure(value=1 if self.cards else 0)
        self.status_var.set(status)
        courses = sorted({c["course"] for c in self.cards})
        self.course_cb.configure(values=[ALL] + courses)
        if self.course_var.get() not in courses:
            self.course_var.set(ALL)
        self.export_btn.configure(state="normal" if self.cards else "disabled")
        self.check_btn.configure(state="normal" if self.cards else "disabled")
        self._refill_races()

    def _show_stats(self):
        s = self.model["stats"]
        parts = []
        for kind in ("flat", "jumps"):
            if (kind, "market") in s:
                m, f = s[(kind, "market")], s[(kind, "form")]
                parts.append(f"{kind}: pick won {100 * m['top_pick']:.0f}% (form only "
                             f"{100 * f['top_pick']:.0f}%, SP fav {100 * m['favourite']:.0f}%)")
        self.stats_var.set(f"Tested on races since {self.model['holdout_from']} — " + "; ".join(parts)
                           + f".  Form file ends {self.model['form_last']}.")

    def _attach_results(self, results):
        for rc in self.cards:
            res = results.get(str(rc["race_id"]))
            if not res:
                continue
            rc["result_stage"] = res["stage"]
            if res.get("runners"):
                finish = {}
                for u in res["runners"]:
                    finish[fm.norm_name(u["horse"])] = u
                    if u.get("horse_id"):
                        finish[str(u["horse_id"])] = u
                rc["finish"] = finish
                rc["winner"] = next((u for u in res["runners"] if u.get("rp_pos") == "1"), None)
                ran = [u for u in res["runners"] if u.get("rp_pos") != "NR" and fm.decimal_odds(u.get("sp"))]
                rc["sp_fav"] = min(ran, key=lambda u: fm.decimal_odds(u["sp"]))["horse"] if ran else ""
        run = sum(1 for rc in self.cards if rc.get("finish"))
        self._done(f"{run} of {len(self.cards)} races run")

    def _finish(self, rc, horse, horse_id=None):
        """The result row for a horse in rc, or None if the race hasn't been run (or it's not found)."""
        finish = rc.get("finish") or {}
        return finish.get(str(horse_id)) if horse_id and str(horse_id) in finish else finish.get(fm.norm_name(horse))

    def _show_results(self, cards):
        """Summarise how each way of picking has done in the races run so far."""
        if not any("result_stage" in rc for rc in cards):
            self.results_var.set("")
            return
        run = [rc for rc in cards if rc.get("finish")]
        abandoned = sum(1 for rc in cards if rc.get("result_stage", rc.get("stage")) == "ABANDONED")
        parts = [f"Results so far: {len(run)} of {len(cards)} races run"
                 + (f" ({abandoned} abandoned)" if abandoned else "")]
        pickers = (("Pick", lambda rc: self._ranked(rc)[0]["horse"]),
                   ("Form-only", lambda rc: rc["form_pick"]),
                   ("Spotlight", lambda rc: rc.get("verdict_1st")),
                   ("SP fav", lambda rc: rc.get("sp_fav")))
        for label, pick in pickers:
            bets = wins = placed = 0
            profit = 0.0
            for rc in run:
                u = self._finish(rc, pick(rc)) if pick(rc) else None
                if not u or u.get("rp_pos") == "NR":
                    continue  # no selection, or a non-runner: stake returned
                bets += 1
                if u.get("rp_pos") == "1":
                    wins += 1
                    profit += (fm.decimal_odds(u.get("sp")) or 1) - 1
                else:
                    profit -= 1
                placed += u.get("rp_pos") in ("1", "2", "3")
            if bets:
                parts.append(f"{label}: {wins}/{bets} won ({100 * wins / bets:.0f}%), {placed} top-3, "
                             f"£1 at SP {profit:+.2f}")
        self.results_var.set("  |  ".join(parts))

    def _log(self, line):
        self.log_text.configure(state="normal")
        self.log_text.insert("end", line + "\n")
        self.log_text.see("end")
        self.log_text.configure(state="disabled")

    # --- display ----------------------------------------------------------

    def _ranked(self, rc):
        key = "p_" + self.rank_var.get()
        return sorted(rc["runners"], key=lambda r: -r[key])

    def _refill_races(self):
        self.race_tree.delete(*self.race_tree.get_children())
        self.runner_tree.delete(*self.runner_tree.get_children())
        self._set_detail([])
        self.by_iid.clear()
        key = "p_" + self.rank_var.get()
        course = self.course_var.get()
        shown = [rc for rc in self.cards if course == ALL or rc["course"] == course]
        for rc in shown:
            r = self._ranked(rc)
            top = r[0]
            value = top["price"] and top[key] * top["price"] > 1.1
            tags = ("value",) if value else ()
            u = self._finish(rc, top["horse"], top.get("horse_id"))
            result = "Abandoned" if rc.get("result_stage", rc.get("stage")) == "ABANDONED" else finish_text(u) if u else ""
            if u and finish_tag(u):
                tags += (finish_tag(u),)
            w = rc.get("winner")
            iid = self.race_tree.insert("", "end", tags=tags, values=(
                rc["time"], rc["course"], rc["race_name"], rc["kind"], len(r), top["horse"],
                pct(top[key]), fm.fair_odds(top[key]), price_text(top["price"]), result,
                f"{r[1]['horse']} {pct(r[1][key])}" if len(r) > 1 else "",
                f"{rc['form_pick']} {pct(rc['form_pick_p'])}", rc.get("verdict_1st", ""),
                f"{w['horse']} {w.get('sp') or ''}".strip() if w else ""))
            self.by_iid[iid] = rc
        self._show_results(shown)

    def _show_race(self, _=None):
        sel = self.race_tree.selection()
        if not sel:
            return
        rc = self.by_iid[sel[0]]
        key = "p_" + self.rank_var.get()
        self.runner_tree.delete(*self.runner_tree.get_children())
        self.runner_rows.clear()
        for n, u in enumerate(self._ranked(rc), 1):
            value = u["price"] * u[key] if u["price"] else None
            tags = (("top",) if n == 1 else ()) + (("value",) if value and value > 1.1 else ())
            fin = self._finish(rc, u["horse"], u.get("horse_id"))
            if fin and finish_tag(fin):
                tags += (finish_tag(fin),)
            iid = self.runner_tree.insert("", "end", tags=tags, values=(
                n, finish_text(fin) if fin else "", u["horse"], pct(u["p_market"]), fm.fair_odds(u[key]), price_text(u["price"]),
                f"{value:.2f}" if value else "", pct(u["p_form"]), u["form_rank"],
                u.get("official_rating", ""), u.get("form", ""), u.get("last_ran_days", ""),
                u["last_clues"], u.get("jockey", ""), u.get("trainer", ""), u.get("verdict_pick", "")))
            self.runner_rows[iid] = (u, rc)
        lines = [("h", f"{rc['time']} {rc['course']} — {rc['race_name']}\n"),
                 ("", f"{rc.get('distance', '')}, {rc.get('going', '')}, class {rc.get('race_class') or '-'}"
                      f", {len(rc['runners'])} runners\n\n")]
        if rc.get("verdict"):
            lines += [("h", "Spotlight\n"), ("", rc["verdict"] + "\n\n")]
        if rc.get("betting_forecast"):
            lines += [("h", "Betting forecast\n"), ("", rc["betting_forecast"] + "\n\n")]
        lines.append(("", "Value = win % × price; over 1.10 (green) means the price looks bigger than "
                          "the horse's chance.\n"))
        self._set_detail(lines)

    def _show_runner(self, _=None):
        sel = self.runner_tree.selection()
        if not sel:
            return
        u, rc = self.runner_rows[sel[0]]
        reasons = u["reasons_" + self.rank_var.get()]
        lines = [("h", f"{u['horse']}  —  {pct(u['p_market'])} (form only {pct(u['p_form'])})\n"),
                 ("", f"Age {u.get('horse_age', '')}, {u.get('weight', '')}, OR {u.get('official_rating') or '-'}"
                      f", form {u.get('form') or '-'}, {u.get('last_ran_days') or '?'} days since last run\n"
                      f"{u.get('jockey', '')} / {u.get('trainer', '')}\n")]
        if not u["in_form_file"]:
            lines.append(("note", f"No runs in the form file (it ends {self.model['form_last']}): "
                                  "using the card's last 3 runs and career totals.\n"))
        lines.append(("h", "\nWhy (strongest first)\n"))
        if not reasons:
            lines.append(("", "Nothing stands out from the field average.\n"))
        for label, v in reasons[:10]:
            lines.append(("up" if v > 0 else "down", f"{'▲' if v > 0 else '▼'} {label}\n"))
        if u["last_comment"]:
            lines += [("h", "\nLast run\n"), ("", u["last_comment"] + "\n")]
        for i in range(1, fm.RECENT + 1):
            if u.get(f"last{i}_date"):
                if i == 1:
                    lines.append(("h", "\nRecent runs (card)\n"))
                lines.append(("", f"{u[f'last{i}_date']} {u.get(f'last{i}_course', '')} "
                                  f"{u.get(f'last{i}_pos', '')}/{u.get(f'last{i}_ran', '')} "
                                  f"{u.get(f'last{i}_dist', '')} {u.get(f'last{i}_going', '')} "
                                  f"{u.get(f'last{i}_odds', '')}\n"))
        if u.get("commentary"):
            lines += [("h", "\nSpotlight\n"), ("", u["commentary"] + "\n")]
        self._set_detail(lines)

    def _set_detail(self, lines):
        self.detail.configure(state="normal")
        self.detail.delete("1.0", "end")
        for tag, text in lines:
            self.detail.insert("end", text, tag or ())
        self.detail.configure(state="disabled")

    def _sort(self, tree, col, reverse):
        def key(v):
            s = str(v).rstrip("%").split("/")[0]
            try:
                return (0, float(s))
            except ValueError:
                return (1, str(v).lower())
        items = sorted(tree.get_children(), key=lambda i: key(tree.set(i, col)), reverse=reverse)
        for n, i in enumerate(items):
            tree.move(i, "", n)
        tree.heading(col, command=lambda: self._sort(tree, col, not reverse))


def main():
    root = tk.Tk()
    root.title("Probable winners")
    root.geometry("1400x850")
    WinnersFrame(root).pack(fill="both", expand=True)
    root.mainloop()


if __name__ == "__main__":
    main()
